package com.epam.rd.autotasks;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class NewPostOffice {
    private final Collection<Box> listBox;
    private static final int COST_KILOGRAM = 5;
    private static final int COST_CUBIC_METER = 100;
    private static final double COEFFICIENT = 0.5;

    public NewPostOffice() {
        listBox = new ArrayList<>();
    }

    public Collection<Box> getListBox() {
        return (Collection<Box>) ((ArrayList<Box>) listBox).clone();
    }

    static BigDecimal calculateCostOfBox(double weight, double volume, int value) {
        BigDecimal costWeight = BigDecimal.valueOf(weight)
                .multiply(BigDecimal.valueOf(COST_KILOGRAM), MathContext.DECIMAL64);
        BigDecimal costVolume = BigDecimal.valueOf(volume)
                .multiply(BigDecimal.valueOf(COST_CUBIC_METER), MathContext.DECIMAL64);
        return costVolume.add(costWeight)
                .add(BigDecimal.valueOf(COEFFICIENT * value), MathContext.DECIMAL64);
    }

    // implements student
    public boolean addBox(String addresser, String recipient, double weight, double volume, int value) {
        if (addresser == null || addresser.trim().isEmpty()) {
            throw new IllegalArgumentException("addresser is empty or null");
        }
        if (recipient == null || recipient.trim().isEmpty()) {
            throw new IllegalArgumentException("recipient is empty or null");
        }
        if (weight < 0.5 || weight > 20.0) {
            throw new IllegalArgumentException("weight is out of range");
        }
        if (volume <= 0 || volume > 0.25) {
            throw new IllegalArgumentException("volume is out of range");
        }
        if (value <= 0) {
            throw new IllegalArgumentException("value is out of range");
        }

        Box newBox = new Box(addresser, recipient, weight, volume);
        newBox.setCost(calculateCostOfBox(weight, volume, value));
        listBox.add(newBox);

        return true;
    }

    // implements student
    public Collection<Box> deliveryBoxToRecipient(String recipient) {
        Collection<Box> output = new ArrayList<>();

        Iterator<Box> iterator = listBox.iterator();
        while (iterator.hasNext()) {
            Box currentBox = iterator.next();
            if (currentBox.getRecipient().equals(recipient)) {
                output.add(currentBox);
                iterator.remove();
            }
        }

        return output;
    }

    public void declineCostOfBox(double percent) {
        for (Box currentBox : listBox) {
            BigDecimal oldCost = currentBox.getCost();
            BigDecimal reduction = oldCost.multiply(BigDecimal.valueOf(percent / 100.0));
            BigDecimal newCost = oldCost.subtract(reduction).round(MathContext.DECIMAL64);
            currentBox.setCost(newCost);
        }
    }
}
