package com.epam.rd.autotasks.collections.predicates;

import com.epam.rd.autotasks.collections.Box;

import java.util.function.Predicate;

public class LessThanPredicate implements Predicate<Box> {
    double threshold;

    public LessThanPredicate(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public boolean test(Box box) {
        return box.getWeight() < this.threshold;
    }
}