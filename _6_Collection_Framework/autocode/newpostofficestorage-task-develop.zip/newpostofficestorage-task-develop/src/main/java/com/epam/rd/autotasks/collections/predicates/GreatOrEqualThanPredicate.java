package com.epam.rd.autotasks.collections.predicates;

import com.epam.rd.autotasks.collections.Box;

import java.util.function.Predicate;

public class GreatOrEqualThanPredicate implements Predicate<Box> {
    double threshold;

    public GreatOrEqualThanPredicate(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public boolean test(Box box) {
        return box.getVolume() >= this.threshold;
    }
}