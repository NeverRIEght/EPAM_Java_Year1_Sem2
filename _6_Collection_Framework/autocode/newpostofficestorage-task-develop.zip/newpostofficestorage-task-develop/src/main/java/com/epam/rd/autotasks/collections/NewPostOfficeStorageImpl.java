package com.epam.rd.autotasks.collections;

import com.epam.rd.autotasks.collections.predicates.GreatOrEqualThanPredicate;
import com.epam.rd.autotasks.collections.predicates.GreatThanPredicate;
import com.epam.rd.autotasks.collections.predicates.LessThanPredicate;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Predicate;

public class NewPostOfficeStorageImpl implements NewPostOfficeStorage {
    private List<Box> parcels;

    /**
     * Creates internal storage for becoming parcels
     */
    public NewPostOfficeStorageImpl() {
        parcels = new LinkedList<>();
    }

    /**
     * Creates own storage and appends all parcels into own storage.
     * It must add either all the parcels or nothing, if an exception occurs.
     *
     * @param boxes a collection of parcels.
     * @throws NullPointerException if the parameter is {@code null}
     *                              or contains {@code null} values.
     */
    public NewPostOfficeStorageImpl(Collection<Box> boxes) {
        this();
        acceptAllBoxes(boxes);
    }

    @Override
    public boolean acceptBox(Box box) {
        if (box == null) throw new NullPointerException();
        return parcels.add(box);
    }

    @Override
    public boolean acceptAllBoxes(Collection<Box> boxes) {
        boolean result = false;
        for (Box box : boxes) {
            boolean currentResult = acceptBox(box);
            if (currentResult) {
                result = currentResult;
            }
        }

        return result;
    }

    @Override
    public boolean carryOutBoxes(Collection<Box> boxes) {
        if (boxes == null) throw new NullPointerException();
        for (Box box : boxes) {
            if (box == null) throw new NullPointerException();
        }

        boolean result = false;
        for (Box box : boxes) {
            boolean currentResult = parcels.remove(box);
            if (currentResult) result = true;
        }

        return result;
    }

    @Override
    public List<Box> carryOutBoxes(Predicate<Box> predicate) {
        if (predicate == null) throw new NullPointerException();
        List<Box> boxes = searchBoxes(predicate);

        if (!carryOutBoxes(boxes)) throw new NullPointerException();
        return boxes;
    }

    @Override
    public List<Box> getAllWeightLessThan(double weight) {
        if (weight <= 0) throw new IllegalArgumentException();
        Predicate<Box> predicate = new LessThanPredicate(weight);
        return searchBoxes(predicate);
    }

    @Override
    public List<Box> getAllCostGreaterThan(BigDecimal cost) {
        if (cost == null) throw new NullPointerException();
        if (cost.doubleValue() < 0) throw new IllegalArgumentException();
        Predicate<Box> predicate = new GreatThanPredicate(cost);
        return searchBoxes(predicate);
    }

    @Override
    public List<Box> getAllVolumeGreaterOrEqual(double volume) {
        if (volume < 0) throw new IllegalArgumentException();
        Predicate<Box> predicate = new GreatOrEqualThanPredicate(volume);
        return searchBoxes(predicate);
    }

    @Override
    public List<Box> searchBoxes(Predicate<Box> predicate) {
        List<Box> output = new ArrayList<>();
        for (Box box : parcels) {
            if (predicate.test(box)) {
                output.add(box);
            }
        }

        return output;
    }

    @Override
    public void updateOfficeNumber(Predicate<Box> predicate, int newOfficeNumber) {
        if (predicate == null) throw new NullPointerException();
        List<Box> boxes = searchBoxes(predicate);

        for (Box box : boxes) {
            box.setOfficeNumber(newOfficeNumber);
        }
    }
}
