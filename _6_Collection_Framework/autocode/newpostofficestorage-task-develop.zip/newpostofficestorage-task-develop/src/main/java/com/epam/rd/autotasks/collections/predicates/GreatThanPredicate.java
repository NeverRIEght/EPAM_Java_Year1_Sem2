package com.epam.rd.autotasks.collections.predicates;

import com.epam.rd.autotasks.collections.Box;

import java.math.BigDecimal;
import java.util.function.Predicate;

public class GreatThanPredicate implements Predicate<Box> {
    BigDecimal threshold;

    public GreatThanPredicate(BigDecimal threshold) {
        this.threshold = threshold;
    }

    @Override
    public boolean test(Box box) {
        return 0 < box.getCost().compareTo(threshold);
    }
}