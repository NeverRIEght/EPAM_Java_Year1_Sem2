package com.epam.rd.autotasks;

import java.util.*;

public class Words {
    private static final int WORD_LENGTH_THRESHOLD = 4;
    private static final int WORD_COUNT_THRESHOLD = 10;

    public String countWords(List<String> lines) {
        Map<String, Integer> wordsMap = new HashMap<>();

        for (String line : lines) {
            String[] stringSplit = line.split("[^\\p{L}\\p{N}]+");

            for (String word : stringSplit) {
                if (word.length() < WORD_LENGTH_THRESHOLD) continue;
                word = word.toLowerCase();
                wordsMap.put(word, wordsMap.getOrDefault(word, 0) + 1);
            }
        }

        Comparator<String> comparator = new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                int result = wordsMap.get(o2).compareTo(wordsMap.get(o1));
                if (result == 0) {
                    return o1.compareTo(o2);
                }
                return result;
            }
        };

        TreeMap<String, Integer> sortedMap = new TreeMap<>(comparator);
        sortedMap.putAll(wordsMap);

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
            int value = entry.getValue();
            if (value < WORD_COUNT_THRESHOLD) continue;
            sb.append(entry.getKey()).append(" - ").append(value).append("\n");
        }

        return sb.toString().trim();
    }
}