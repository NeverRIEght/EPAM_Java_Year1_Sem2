package com.epam.rd.autotasks.collections;

import spoon.support.util.SortedList;

import java.util.*;

public class BirthJournalManagementImpl implements BirthJournalManagement {

    Map<WeekDay, List<Baby>> journal = new EnumMap<>(WeekDay.class);
    boolean isImmutable = false;

    @Override
    public boolean addEntryOfBaby(WeekDay day, Baby baby) {
        if (isImmutable) return false;

        if (journal.get(day) == null) {
            journal.put(day, new ArrayList<>());
        }

        journal.get(day).add(baby);

        return true;
    }

    @Override
    public void commit() {
        isImmutable = true;
    }

    @Override
    public int amountBabies() {
        int size = 0;
        for (List<Baby> babies : journal.values()) {
            size += babies.size();
        }

        return size;
    }

    @Override
    public List<Baby> findBabyWithHighestWeight(String gender) {
        Comparator<Baby> babyTimeComparator = new Comparator<>() {
            @Override
            public int compare(Baby o1, Baby o2) {
                String time1 = o1.getTime();
                String time2 = o2.getTime();
                return getTimeComparator().compare(time1, time2);
            }
        };

        Comparator<Baby> weightComparator = new Comparator<>() {
            @Override
            public int compare(Baby o1, Baby o2) {
                return Double.compare(o1.getWeight(), o2.getWeight());
            }
        };

        List<Baby> babies = new ArrayList<>();
        for (List<Baby> babiesList : journal.values()) {
            for (Baby baby : babiesList) {
                if (baby.getGender().equals(gender)) {
                    babies.add(baby);
                }
            }
        }

        babies.sort(weightComparator.reversed());

        for (int i = 0; i < babies.size(); i++) {
            if (babies.get(i).getWeight() != babies.get(0).getWeight()) {
                babies = babies.subList(0, i);
                break;
            }
        }

        babies.sort(babyTimeComparator);

        return babies;
    }

    @Override
    public List<Baby> findBabyWithSmallestHeight(String gender) {
        Comparator<Baby> heightComparator = new Comparator<>() {
            @Override
            public int compare(Baby o1, Baby o2) {
                int result = Integer.compare(o1.getHeight(), o2.getHeight());
                if (result != 0) return result;

                return Double.compare(o1.getWeight(), o2.getWeight());
            }
        };

        List<Baby> output = new SortedList<>(heightComparator);
        for (Map.Entry<WeekDay, List<Baby>> entry : journal.entrySet()) {
            List<Baby> babies = journal.get(entry.getKey());

            for (Baby baby : babies) {
                if (baby.getGender().equals(gender)) {
                    output.add(baby);
                }
            }
        }

        for (int i = 0; i < output.size(); i++) {
            if (output.get(i).getHeight() != output.get(0).getHeight()) {
                output = output.subList(0, i);
                break;
            }
        }

        return Collections.unmodifiableList(output);
    }

    @Override
    public Set<Baby> findBabiesByBirthTime(String from, String to) {
        Comparator<String> timeComparator = getTimeComparator();
        Set<Baby> output = new HashSet<>();

        for (Map.Entry<WeekDay, List<Baby>> entry : journal.entrySet()) {
            List<Baby> babies = journal.get(entry.getKey());

            for (Baby baby : babies) {
                String time = baby.getTime();

                if (timeComparator.compare(from, time) <= 0 && timeComparator.compare(time, to) <= 0) {
                    output.add(baby);
                }
            }
        }

        return output;
    }

    private Comparator<String> getTimeComparator() {
        return new Comparator<>() {
            @Override
            public int compare(String time1, String time2) {
                int hours1 = Integer.parseInt(time1.split(":")[0]);
                int minutes1 = Integer.parseInt(time1.split(":")[1]);

                int hours2 = Integer.parseInt(time2.split(":")[0]);
                int minutes2 = Integer.parseInt(time2.split(":")[1]);

                int result = Integer.compare(hours1, hours2);
                if (result != 0) return result;

                result = Integer.compare(minutes1, minutes2);
                return result;
            }
        };
    }
}
