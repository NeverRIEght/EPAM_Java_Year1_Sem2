package com.epam.rd.autotasks.collections;

public class Main {
    public static void main(String[] args) {
        // This class is not under tests
        // You can use this class for your own purposes
    }
}
