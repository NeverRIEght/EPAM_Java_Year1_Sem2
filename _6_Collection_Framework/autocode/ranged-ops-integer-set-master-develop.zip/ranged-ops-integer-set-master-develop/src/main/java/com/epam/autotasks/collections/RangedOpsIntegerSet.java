package com.epam.autotasks.collections;

import java.util.*;

class RangedOpsIntegerSet extends AbstractSet<Integer> {

    private final Set<Integer> set = new TreeSet<>();

    public boolean add(int fromInclusive, int toExclusive) {
        if (toExclusive - 1 < fromInclusive) {
            throw new IllegalArgumentException();
        }

        boolean commonResult = false;
        for (int i = fromInclusive; i < toExclusive; i++) {
            if(this.add(i)) {
                commonResult = true;
            }
        }

        return commonResult;
    }

    public boolean remove(int fromInclusive, int toExclusive) {
        if (toExclusive - 1 < fromInclusive) {
            throw new IllegalArgumentException();
        }

        boolean commonResult = false;
        for (int i = fromInclusive; i < toExclusive; i++) {
            if(this.remove(i)) {
                commonResult = true;
            }
        }

        return commonResult;
    }

    @Override
    public boolean add(final Integer integer) {
        return set.add(integer);
    }

    @Override
    public boolean remove(final Object o) {
        return set.remove(o);
    }

    @Override
    public Iterator<Integer> iterator() {
        return this.set.iterator();
    }

    @Override
    public int size() {
        return this.set.size();
    }
}
