package com.epam.rd.autocode.queue;

import java.util.*;

import com.epam.rd.autocode.queue.CashBox.State;


public class Shop {

    private int cashBoxCount;

    private List<CashBox> cashBoxes;

    public Shop(int count) {
        cashBoxCount = count;
        cashBoxes = new ArrayList<>(cashBoxCount);
        for (int i = 0; i < cashBoxCount; i++) {
            cashBoxes.add(new CashBox(i));
        }
    }

    public int getCashBoxCount() {
        return cashBoxCount;
    }

    public void addBuyer(Buyer buyer) {
        CashBox leastLoadedCashBox = getLeastLoadedCashbox();
        if (leastLoadedCashBox != null) {
            leastLoadedCashBox.addLast(buyer);
        }
    }

    public CashBox getLeastLoadedCashbox() {
        CashBox leastLoadedCashbox = null;
        for (CashBox currentCashBox : cashBoxes) {
            if (currentCashBox.inState(State.ENABLED)) {
                if (leastLoadedCashbox == null) {
                    leastLoadedCashbox = currentCashBox;
                    continue;
                }
                if (leastLoadedCashbox.getQueue().size() > currentCashBox.getQueue().size()) {
                    leastLoadedCashbox = currentCashBox;
                }
            }
        }

        return leastLoadedCashbox;
    }

    public void tact() {
        for (CashBox cb : cashBoxes) {
            cb.serveBuyer();
        }

        for (CashBox cb : cashBoxes) {
            if (cb.notInState(State.DISABLED)) {
                balance();
            }
        }
    }

    public void setCashBoxState(int cashBoxNumber, State state) {
        getCashBox(cashBoxNumber).setState(state);
    }

    public CashBox getCashBox(int cashBoxNumber) {
        return cashBoxes.get(cashBoxNumber);
    }

    public void balance() {
        for (int i = 0; i < cashBoxes.size(); i++) {
            CashBox currentCashBox = cashBoxes.get(i);
            if (currentCashBox.notInState(State.DISABLED)) {
                CashBox destination = getNextCashBox(cashBoxes, i);
                if (destination == null) continue;

                Buyer defector = currentCashBox.removeLast();
                if (defector == null) continue;

                destination.addLast(defector);
            }
        }
    }

    private static CashBox getNextCashBox(List<CashBox> cashBoxes, int currentIndex) {
        CashBox cashBoxToCompare = cashBoxes.get(currentIndex);
        int queueSizeToCompare = cashBoxToCompare.getQueue().size();

        for (int i = currentIndex + 1; i < cashBoxes.size(); i++) {
            CashBox currentCashBox = cashBoxes.get(i);
            int currentQueueSize = currentCashBox.getQueue().size();
            if (currentCashBox.notInState(State.ENABLED)) continue;
            if(currentQueueSize < queueSizeToCompare) {
                if (currentQueueSize + 1 == queueSizeToCompare) {
                    continue;
                }
                return currentCashBox;
            }
        }

        return null;
    }

    public void print() {
        System.out.println(this);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < cashBoxCount; i++) {
            sb.append(cashBoxes.get(i).toString()).append("\n");
        }

        return sb.toString().trim();
    }
}
