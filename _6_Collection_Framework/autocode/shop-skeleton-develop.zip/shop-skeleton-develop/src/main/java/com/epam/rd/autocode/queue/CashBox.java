package com.epam.rd.autocode.queue;

import java.util.ArrayDeque;
import java.util.Deque;


public class CashBox {

    private int number;

    private Deque<Buyer> byers;

    private State state;

    public enum State {
        ENABLED, DISABLED, IS_CLOSING
    }

    public CashBox(int number) {
        this.number = number;
        this.state = State.DISABLED;
        this.byers = new ArrayDeque<>();
    }

    public Deque<Buyer> getQueue() {
        return new ArrayDeque<>(byers);
    }

    public Buyer serveBuyer() {
        if (!inState(State.DISABLED) && !byers.isEmpty()) {
            Buyer buyer = byers.poll();

            if (byers.isEmpty() && inState(State.IS_CLOSING)) {
                setState(State.DISABLED);
            }

            return buyer;
        }

        return null;
    }

    public boolean inState(State state) {
        return state.equals(this.state);
    }

    public boolean notInState(State state) {
        return !state.equals(this.state);
    }

    public void setState(State state) {
        this.state = state;
    }

    public State getState() {
        return this.state;
    }

    public void addLast(Buyer buyer) {
        if (inState(State.ENABLED)) {
            byers.offer(buyer);
        }
    }

    public Buyer removeLast() {
        if (notInState(State.DISABLED) && !byers.isEmpty()) {
            Buyer buyer = byers.removeLast();

            if (byers.isEmpty() && inState(State.IS_CLOSING)) {
                setState(State.DISABLED);
            }

            return buyer;
        }

        return null;
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();

        String cashBoxState = switch (getState()) {
            case ENABLED -> "+";
            case DISABLED -> "-";
            case IS_CLOSING -> "|";
        };

        output.append(String.format("#%d[%s]", number, cashBoxState));
        for (Buyer b : getQueue()) {
            output.append(b);
        }

        return output.toString();
    }
}
