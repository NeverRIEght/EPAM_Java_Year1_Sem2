package com.epam.rd.autocode.queue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Random;
import java.util.Set;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.epam.rd.autocode.queue.CashBox.State;

import spoon.Launcher;
import spoon.SpoonAPI;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.visitor.filter.TypeFilter;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author D. Kolesnikov
 */
public class ShopTest {

    //////////////////////////////////////////////////////////////////////////////

    private static boolean isAllTestsMustFailed;

    private static Throwable complianceTestFailedCause;

    static {
        try {
            String testClassName = new Exception().getStackTrace()[0].getClassName();
            String className = testClassName.substring(0, testClassName.lastIndexOf("Test"));
            Class<?> c = Class.forName(className);

            java.lang.reflect.Method[] methods = {
                    c.getDeclaredMethod("addBuyer", Buyer.class),
                    c.getDeclaredMethod("getCashBox", int.class),
                    c.getDeclaredMethod("setCashBoxState", int.class, CashBox.State.class),
                    c.getDeclaredMethod("tact"),
                    c.getDeclaredMethod("print")
            };

            org.apache.bcel.classfile.JavaClass jc = org.apache.bcel.Repository.lookupClass(c);
            for (java.lang.reflect.Method method : methods) {
                org.apache.bcel.classfile.Method m = jc.getMethod(method);
                org.apache.bcel.classfile.Code code = m.getCode();
                Assertions.assertTrue(code.getCode().length > 2, () -> m + " is not a stub");
            }
        } catch (Throwable t) {
            isAllTestsMustFailed = true;
            complianceTestFailedCause = t;
            t.printStackTrace();
        }
    }

    {
        if (isAllTestsMustFailed) {
            Assertions.fail(() -> "Compliance test failed: " + complianceTestFailedCause.getMessage());
        }
    }

    //////////////////////////////////////////////////////////////////////////////

    private static final PrintStream STD_OUT = System.out;

    private Shop shop;

    @BeforeEach
    void setUp() {
        Buyer.resetNames();
        shop = new Shop(5);
    }

    @Test
    void test1() {
        shop.setCashBoxState(0, State.ENABLED);

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(2, State.ENABLED);
        shop.tact();

        //+B
        //
        //+C
        //
        //
        assertEquals("+B-+C--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        //+BD
        //
        //+CE
        //
        //
        assertEquals("+BD-+CE--", getState(shop));

        shop.setCashBoxState(4, State.ENABLED);
        shop.tact();

        //+D
        //
        //+E
        //
        //+
        assertEquals("+D-+E-+", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        //+DG
        //
        //+E
        //
        //+F
        assertEquals("+DG-+E-+F", getState(shop));

        String actual = getState(shop);
        String expected = "+DG-+E-+F";
        assertEquals(expected, actual);
    }

    @Test
    void test2() {
        shop.setCashBoxState(0, State.ENABLED);

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(2, State.ENABLED);

        //+ABCDE
        //
        //+
        //
        //
        assertEquals("+ABCDE-+--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        //+ABCDE
        //
        //+FGHI
        //
        //
        assertEquals("+ABCDE-+FGHI--", getState(shop));


        shop.setCashBoxState(1, State.ENABLED);
        shop.setCashBoxState(3, State.ENABLED);

        //+ABCDE
        //+
        //+FGHI
        //+
        //
        assertEquals("+ABCDE++FGHI+-", getState(shop));

        shop.tact();

        //+BC
        //+ED
        //+GH
        //+I
        //
        assertEquals("+BC+ED+GH+I-", getState(shop));

        String actual = getState(shop);
        String expected = "+BC+ED+GH+I-";
        assertEquals(expected, actual);
    }

    @Test
    void test3() {
        shop.setCashBoxState(0, State.ENABLED);

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(2, State.ENABLED);

        //+ABCDE
        //
        //+
        //
        //
        assertEquals("+ABCDE-+--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(2, State.IS_CLOSING);

        //+ABCDE
        //
        //|FGHI
        //
        //
        assertEquals("+ABCDE-|FGHI--", getState(shop));

        shop.tact();

        //+BCDE
        //
        //|GHI
        //
        //
        assertEquals("+BCDE-|GHI--", getState(shop));

        String actual = getState(shop);
        String expected = "+BCDE-|GHI--";
        assertEquals(expected, actual);
    }

    @Test
    void test4() {
        shop.setCashBoxState(0, State.ENABLED);

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(2, State.ENABLED);

        //+ABCDE
        //
        //+
        //
        //
        assertEquals("+ABCDE-+--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(2, State.IS_CLOSING);

        //+ABCDE
        //
        //|FGHI
        //
        //
        assertEquals("+ABCDE-|FGHI--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        //+ABCDEJKLM
        //
        //|FGHI
        //
        //
        assertEquals("+ABCDEJKLM-|FGHI--", getState(shop));

        shop.tact();

        //+BCDEJKLM
        //
        //|GHI
        //
        //
        assertEquals("+BCDEJKLM-|GHI--", getState(shop));

        shop.setCashBoxState(3, State.ENABLED);

        //+BCDEJKLM
        //
        //|GHI
        //+
        //
        assertEquals("+BCDEJKLM-|GHI+-", getState(shop));

        shop.tact();

        //+CDEJ
        //
        //|HI
        //+MLK
        //
        assertEquals("+CDEJ-|HI+MLK-", getState(shop));

        String actual = getState(shop);
        assertTrue(Set.of("+CDEJ-|HI+MLK-", "+CDE-|HI+MLKJ-").contains(actual));
    }

    @Test
    void test5() {
        shop.setCashBoxState(0, State.ENABLED);

        shop.addBuyer(Buyer.nextBuyer()); //A
        shop.addBuyer(Buyer.nextBuyer()); //B
        shop.addBuyer(Buyer.nextBuyer()); //C
        shop.addBuyer(Buyer.nextBuyer()); //D
        shop.addBuyer(Buyer.nextBuyer()); //E

        shop.setCashBoxState(2, State.ENABLED);

        //+ABCDE
        //
        //+
        //
        //
        assertEquals("+ABCDE-+--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer()); //F
        shop.addBuyer(Buyer.nextBuyer()); //G
        shop.addBuyer(Buyer.nextBuyer()); //H
        shop.addBuyer(Buyer.nextBuyer()); //I

        //+ABCDE
        //
        //+FGHI
        //
        //
        assertEquals("+ABCDE-+FGHI--", getState(shop));

        shop.setCashBoxState(2, State.IS_CLOSING);

        //+ABCDE
        //
        //|FGHI
        //
        //
        assertEquals("+ABCDE-|FGHI--", getState(shop));

        shop.addBuyer(Buyer.nextBuyer()); //J
        shop.addBuyer(Buyer.nextBuyer()); //K
        shop.addBuyer(Buyer.nextBuyer()); //L
        shop.addBuyer(Buyer.nextBuyer()); //M

        //+ABCDEJKLM
        //
        //|FGHI
        //
        //
        assertEquals("+ABCDEJKLM-|FGHI--", getState(shop));

        shop.tact();

        //+BCDEJKLM
        //
        //|GHI
        //
        //
        assertEquals("+BCDEJKLM-|GHI--", getState(shop));

        shop.setCashBoxState(3, State.ENABLED);

        //+BCDEJKLM
        //
        //|GHI
        //+
        //
        assertEquals("+BCDEJKLM-|GHI+-", getState(shop));

        shop.tact();

        //+CDEJ
        //
        //|HI
        //+MLK
        //
        assertEquals("+CDEJ-|HI+MLK-", getState(shop));

        shop.addBuyer(Buyer.nextBuyer()); //N
        shop.addBuyer(Buyer.nextBuyer()); //O
        shop.addBuyer(Buyer.nextBuyer()); //P
        shop.addBuyer(Buyer.nextBuyer()); //Q

        //+CDEJOQ
        //
        //|HI
        //+MLKNP
        //
        assertEquals("+CDEJOQ-|HI+MLKNP-", getState(shop));

        String actual = getState(shop);
        String expected = "+CDEJOQ-|HI+MLKNP-";
        assertEquals(expected, actual);
    }

    @Test
    void test6() throws IOException {
        shop.setCashBoxState(0, State.ENABLED);

        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());
        shop.addBuyer(Buyer.nextBuyer());

        shop.setCashBoxState(1, State.ENABLED);
        shop.addBuyer(Buyer.nextBuyer());

        //+ABCD
        //+E
        //
        //
        //
        assertEquals("+ABCD+E---", getState(shop));

        shop.setCashBoxState(0, State.IS_CLOSING);

        //|ABCD
        //+E
        //
        //
        //
        assertEquals("|ABCD+E---", getState(shop));

        shop.addBuyer(Buyer.nextBuyer());

        //|ABCD
        //+EF
        //
        //
        //
        assertEquals("|ABCD+EF---", getState(shop));

        shop.tact();

        //|BC
        //+FD
        //
        //
        //
        assertEquals("|BC+FD---", getState(shop));

        String actual = getState(shop);
        String expected = "|BC+FD---";
        assertEquals(expected, actual);
    }

    @Test
    void complianceTestLambdaExpressionsAreRestrictedForUsing() {
        Stream.of(Shop.class)
                .map(Class::getDeclaredMethods)
                .flatMap(Stream::of)
                .filter(m -> Modifier.isStatic(m.getModifiers()))
                .filter(m -> Modifier.isPrivate(m.getModifiers()))
                .map(Method::getName)
                .filter(name -> name.contains("lambda$"))
                .findAny()
                .ifPresent(m ->
                        fail(() -> "Using of lambda expressions is restricted: " + m));
    }

    @Test
    void appShouldUseOnlyOptionalFromJavaUtilPackage() {
        SpoonAPI spoon = new Launcher();
        spoon.addInputResource("src/main/java/");
        spoon.buildModel();

        spoon.getModel()
                .getElements(new TypeFilter<>(CtTypeReference.class))
                .stream()
                .filter(r -> r.toString().startsWith("java.util.stream"))
                .map(CtTypeReference::getQualifiedName)
                .findAny()
                .ifPresent(name ->
                        fail(() -> "Using of stream API is restricted: " + name));
    }

    @Test
    void addBuyerShouldAddBuyerToProperCashBoxWhenThereAreMoreThanOneShortestQueues() {
        shop = new Shop(3);
        for (int j = 0; j < 3; j++) {
            shop.getCashBox(j).setState(State.ENABLED);
        }

        shop.addBuyer(Buyer.nextBuyer());
        assertEquals(shop.getCashBox(0).getQueue().getLast().toString(), "A");

        shop.addBuyer(Buyer.nextBuyer());
        assertEquals(shop.getCashBox(1).getQueue().getLast().toString(), "B");

        shop.addBuyer(Buyer.nextBuyer());
        assertEquals(shop.getCashBox(2).getQueue().getLast().toString(), "C");

        shop.addBuyer(Buyer.nextBuyer());
        assertEquals(shop.getCashBox(0).getQueue().getLast().toString(), "D");
    }

    @Test
    void printShouldWorkProperly() throws IOException {
        shop = new Shop(3);
        String actual = null;
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             PrintStream ps = new PrintStream(baos)) {
            System.setOut(ps);

            shop.setCashBoxState(0, State.ENABLED);
            shop.setCashBoxState(1, State.ENABLED);
            shop.setCashBoxState(2, State.ENABLED);
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());

            shop.setCashBoxState(0, State.IS_CLOSING);
            shop.tact();
            shop.addBuyer(Buyer.nextBuyer());

            shop.setCashBoxState(1, State.IS_CLOSING);
            shop.addBuyer(Buyer.nextBuyer());
            shop.addBuyer(Buyer.nextBuyer());
            shop.tact();
            shop.tact();

            shop.print();
            actual = baos.toString();
        } finally {
            System.setOut(STD_OUT);
        }

        actual = actual.replaceAll("\r", "").trim();
        String expected = "#0[-]~#1[|]J~#2[+]KL".replace('~', '\n');
        assertEquals(expected, actual);
    }

    private static String getState(Shop shop) {
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < shop.getCashBoxCount(); j++) {
            CashBox cashBox = shop.getCashBox(j);
            State s = cashBox.getState();
            sb.append(s == State.ENABLED ? '+' : (s == State.DISABLED ? '-' : '|'));
            for (Buyer b : shop.getCashBox(j).getQueue()) {
                sb.append(b);
            }
        }
        return sb.toString();
    }

    @Test
    void neverSetCashBoxStateTest() {
        Shop shop1 = new Shop(1);
        shop1.setCashBoxState(0, State.ENABLED);
        assertEquals(State.ENABLED, shop1.getCashBox(0).getState());

        shop1.setCashBoxState(0, State.DISABLED);
        assertEquals(State.DISABLED, shop1.getCashBox(0).getState());

        shop1.setCashBoxState(0, State.IS_CLOSING);
        assertEquals(State.IS_CLOSING, shop1.getCashBox(0).getState());
    }

    @Test
    void neverCashBoxCountTest() {
        Shop shop1 = new Shop(1);
        assertEquals(1, shop1.getCashBoxCount());

        shop1 = new Shop(2);
        assertEquals(2, shop1.getCashBoxCount());

        shop1 = new Shop(3);
        assertEquals(3, shop1.getCashBoxCount());

        Random rand = new Random();
        for (int k = 0; k < 100; k++) {
            int randomValue = rand.nextInt(500) + 1;
            shop1 = new Shop(randomValue);
            assertEquals(randomValue, shop1.getCashBoxCount());
            assertEquals(State.DISABLED, shop1.getCashBox(randomValue - 1).getState());

            Shop finalShop = shop1;
            assertThrows(IndexOutOfBoundsException.class, () -> finalShop.getCashBox(randomValue));
        }
    }

    @Test
    void neverAddBuyerCountTest() {
        Random rand = new Random();
        for (int k = 0; k < 100; k++) {
            final int cashBoxesCount = rand.nextInt(200) + 1;
            final int buyersCount = rand.nextInt(200) + 1;
            final int minBuyersCount = buyersCount / cashBoxesCount;
            final int maxBuyersCount = minBuyersCount + 1;

            Shop shop1 = new Shop(cashBoxesCount);

            for (int i = 0; i < cashBoxesCount; i++) {
                shop1.setCashBoxState(i, State.ENABLED);
            }

            Buyer.resetNames();
            for (int i = 0; i < buyersCount; i++) {
                shop1.addBuyer(Buyer.nextBuyer());
            }

            int actualCountOfByers = 0;
            for (int i = 0; i < cashBoxesCount; i++) {
                CashBox currentCashBox = shop1.getCashBox(i);
                int countOfBuyerAtCashBox = currentCashBox.getQueue().size();
                assertTrue(countOfBuyerAtCashBox >= minBuyersCount);
                assertTrue(countOfBuyerAtCashBox <= maxBuyersCount);
                actualCountOfByers += currentCashBox.getQueue().size();
            }

            assertEquals(buyersCount, actualCountOfByers);
        }
    }

    @Test
    void neverGetLeastLoadedCashBox() {
        Shop shop1 = new Shop(2);

        shop1.setCashBoxState(0, State.ENABLED);
        shop1.setCashBoxState(1, State.ENABLED);
        assertEquals(shop1.getCashBox(0), shop1.getLeastLoadedCashbox());

        Buyer.resetNames();
        shop1.addBuyer(Buyer.nextBuyer()); //A
        assertEquals(shop1.getCashBox(1), shop1.getLeastLoadedCashbox());

        shop1.addBuyer(Buyer.nextBuyer()); //B
        assertEquals(shop1.getCashBox(0), shop1.getLeastLoadedCashbox());

        shop1.addBuyer(Buyer.nextBuyer()); //C
        assertEquals(shop1.getCashBox(1), shop1.getLeastLoadedCashbox());

        shop1.setCashBoxState(1, State.IS_CLOSING);
        assertEquals(shop1.getCashBox(0), shop1.getLeastLoadedCashbox());

        shop1.setCashBoxState(1, State.DISABLED);
        assertEquals(shop1.getCashBox(0), shop1.getLeastLoadedCashbox());

        shop1.addBuyer(Buyer.nextBuyer()); //D
        shop1.addBuyer(Buyer.nextBuyer()); //E
        shop1.setCashBoxState(1, State.ENABLED);
        assertEquals(shop1.getCashBox(1), shop1.getLeastLoadedCashbox());

        shop1.addBuyer(Buyer.nextBuyer()); //F
        shop1.addBuyer(Buyer.nextBuyer()); //G
        assertEquals(shop1.getCashBox(1), shop1.getLeastLoadedCashbox());
    }

    @Test
    void neverToStringTest() {
        Shop shop1 = new Shop(1);
        assertEquals("#0[-]", shop1.toString());

        shop1 = new Shop(2);
        assertEquals("#0[-]\n" + "#1[-]", shop1.toString());

        shop1 = new Shop(4);
        assertEquals("""
                #0[-]
                #1[-]
                #2[-]
                #3[-]""", shop1.toString());

        shop1.setCashBoxState(0, State.ENABLED);
        shop1.setCashBoxState(2, State.ENABLED);
        assertEquals("""
                #0[+]
                #1[-]
                #2[+]
                #3[-]""", shop1.toString());

        shop1.setCashBoxState(1, State.IS_CLOSING);
        shop1.setCashBoxState(3, State.DISABLED);
        assertEquals("""
                #0[+]
                #1[|]
                #2[+]
                #3[-]""", shop1.toString());

        Buyer.resetNames();
        shop1.addBuyer(Buyer.nextBuyer()); //A
        assertEquals("""
                #0[+]A
                #1[|]
                #2[+]
                #3[-]""", shop1.toString());

        shop1.addBuyer(Buyer.nextBuyer()); //B
        assertEquals("""
                #0[+]A
                #1[|]
                #2[+]B
                #3[-]""", shop1.toString());

        shop1.addBuyer(Buyer.nextBuyer()); //C
        assertEquals("""
                #0[+]AC
                #1[|]
                #2[+]B
                #3[-]""", shop1.toString());

        shop1.setCashBoxState(2, State.IS_CLOSING);
        shop1.addBuyer(Buyer.nextBuyer()); //D
        assertEquals("""
                #0[+]ACD
                #1[|]
                #2[|]B
                #3[-]""", shop1.toString());
    }
}
