package com.epam.rd.autocode.queue;

import java.util.Deque;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author D. Kolesnikov
 */
public class CashBoxTest {

	private static boolean isAllTestsMustFailed;

	private static Throwable complianceTestFailedCause;

	static {
		try {
			String testClassName = new Exception().getStackTrace()[0].getClassName();
			String className = testClassName.substring(0, testClassName.lastIndexOf("Test"));
			Class<?> c = Class.forName(className);

			java.lang.reflect.Method[] methods = { 
					c.getDeclaredMethod("getQueue"),
					c.getDeclaredMethod("serveBuyer"),
					c.getDeclaredMethod("inState", CashBox.State.class),
					c.getDeclaredMethod("notInState", CashBox.State.class),
					c.getDeclaredMethod("addLast", Buyer.class),
					c.getDeclaredMethod("removeLast"),
					c.getDeclaredMethod("toString"),
					c.getDeclaredMethod("setState", CashBox.State.class),
					c.getDeclaredMethod("getState")
				};

			   
			org.apache.bcel.classfile.JavaClass jc = org.apache.bcel.Repository.lookupClass(c);
			for (java.lang.reflect.Method method : methods) {
				org.apache.bcel.classfile.Method m = jc.getMethod(method);
				org.apache.bcel.classfile.Code code = m.getCode();
				Assertions.assertTrue(code.getCode().length > 2, () -> m + " is not a stub");
			}
		} catch (Throwable t) {
			isAllTestsMustFailed = true;
			complianceTestFailedCause = t;
			t.printStackTrace();
		}
	}

	{
		if (isAllTestsMustFailed) {
			Assertions.fail(() -> "Compliance test failed: " + complianceTestFailedCause.getMessage());
		}
	}
	
	@Test
	void test() {
		CashBox cb = new CashBox(0);
		cb.addLast(Buyer.nextBuyer());
		Deque<Buyer> q1 = cb.getQueue();
		Deque<Buyer> q2 = cb.getQueue();
		
		Assertions.assertIterableEquals(q1, q2);
		Assertions.assertNotSame(q1, q2);
	
			
	}

	@Test
	void neverCashBoxStatesTest() {
		CashBox cashBox = new CashBox(1);
        assertTrue(cashBox.inState(CashBox.State.DISABLED));

		cashBox.setState(CashBox.State.ENABLED);
        assertFalse(cashBox.inState(CashBox.State.DISABLED));
        assertTrue(cashBox.notInState(CashBox.State.DISABLED));
		assertEquals(CashBox.State.ENABLED, cashBox.getState());

		cashBox.setState(CashBox.State.IS_CLOSING);
        assertFalse(cashBox.inState(CashBox.State.ENABLED));
        assertTrue(cashBox.notInState(CashBox.State.DISABLED));
		assertEquals(CashBox.State.IS_CLOSING, cashBox.getState());

		cashBox.setState(CashBox.State.ENABLED);
        assertFalse(cashBox.inState(CashBox.State.DISABLED));
        assertTrue(cashBox.notInState(CashBox.State.IS_CLOSING));
		assertEquals(CashBox.State.ENABLED, cashBox.getState());
	}

	@Test
	void neverCashBoxAddRemoveTest() {
		CashBox cashBox = new CashBox(1);

		Buyer.resetNames();
		cashBox.addLast(Buyer.nextBuyer()); //A
		assertEquals("#1[-]", cashBox.toString());

		cashBox.setState(CashBox.State.IS_CLOSING);
		cashBox.addLast(Buyer.nextBuyer()); //B
		assertEquals("#1[|]", cashBox.toString());

		cashBox.setState(CashBox.State.ENABLED);
		cashBox.addLast(Buyer.nextBuyer()); //C
		assertEquals("#1[+]C", cashBox.toString());

		cashBox.setState(CashBox.State.IS_CLOSING);
		cashBox.addLast(Buyer.nextBuyer()); //D
		assertEquals("#1[|]C", cashBox.toString());

		cashBox.setState(CashBox.State.ENABLED);
		cashBox.addLast(Buyer.nextBuyer()); //E
		cashBox.addLast(Buyer.nextBuyer()); //F
		assertEquals("#1[+]CEF", cashBox.toString());

		cashBox.removeLast();
		assertEquals("#1[+]CE", cashBox.toString());

		cashBox.setState(CashBox.State.DISABLED);
		cashBox.removeLast();
		assertEquals("#1[-]CE", cashBox.toString());

		cashBox.setState(CashBox.State.IS_CLOSING);
		cashBox.removeLast();
		assertEquals("#1[|]C", cashBox.toString());

		cashBox.removeLast();
		assertEquals("#1[-]", cashBox.toString());
	}

	@Test
	void neverCashBoxAutoClosureTest() {
		CashBox cashBox = new CashBox(1);

		Buyer.resetNames();
		cashBox.addLast(Buyer.nextBuyer()); //A
		cashBox.addLast(Buyer.nextBuyer()); //B
		assertEquals("#1[-]", cashBox.toString());

		cashBox.setState(CashBox.State.IS_CLOSING);
		cashBox.addLast(Buyer.nextBuyer()); //C
		assertEquals("#1[|]", cashBox.toString());

		cashBox.setState(CashBox.State.ENABLED);
		cashBox.addLast(Buyer.nextBuyer()); //D
		cashBox.addLast(Buyer.nextBuyer()); //E
		assertEquals("#1[+]DE", cashBox.toString());

		cashBox.serveBuyer();
		cashBox.serveBuyer();
		assertEquals("#1[+]", cashBox.toString());

		cashBox.addLast(Buyer.nextBuyer()); //F
		cashBox.addLast(Buyer.nextBuyer()); //G
		assertEquals("#1[+]FG", cashBox.toString());

		cashBox.setState(CashBox.State.IS_CLOSING);
		cashBox.serveBuyer();
		assertEquals("#1[|]G", cashBox.toString());

		cashBox.serveBuyer();
		assertEquals("#1[-]", cashBox.toString());
	}

	@Test
	void neverCashBoxTest() {
		CashBox cashBox = new CashBox(1);
		assertEquals("#1[-]", cashBox.toString());

		cashBox = new CashBox(254);
		assertEquals("#254[-]", cashBox.toString());

		cashBox.addLast(Buyer.nextBuyer());
		assertEquals("#254[-]", cashBox.toString());

		cashBox.setState(CashBox.State.ENABLED);
		Buyer.resetNames();
		cashBox.addLast(Buyer.nextBuyer()); //A
		assertEquals("#254[+]A", cashBox.toString());

		cashBox.addLast(Buyer.nextBuyer()); //B
		cashBox.addLast(Buyer.nextBuyer()); //C
		assertEquals("#254[+]ABC", cashBox.toString());

		cashBox.setState(CashBox.State.IS_CLOSING);
		cashBox.addLast(Buyer.nextBuyer()); //D
		cashBox.addLast(Buyer.nextBuyer()); //E
		assertEquals("#254[|]ABC", cashBox.toString());

		cashBox.setState(CashBox.State.DISABLED);
		cashBox.addLast(Buyer.nextBuyer()); //F
		cashBox.addLast(Buyer.nextBuyer()); //G
		assertEquals("#254[-]ABC", cashBox.toString());

		cashBox.setState(CashBox.State.DISABLED);
		cashBox.addLast(Buyer.nextBuyer()); //H
		assertEquals("#254[-]ABC", cashBox.toString());

		cashBox.setState(CashBox.State.ENABLED);
		cashBox.addLast(Buyer.nextBuyer()); //I
		assertEquals("#254[+]ABCI", cashBox.toString());

		cashBox.serveBuyer();
		assertEquals("#254[+]BCI", cashBox.toString());

		Buyer.resetNames();
		cashBox.addLast(Buyer.nextBuyer()); //A
		assertEquals("#254[+]BCIA", cashBox.toString());

		cashBox.serveBuyer();
		cashBox.serveBuyer();
		assertEquals("#254[+]IA", cashBox.toString());

		cashBox.serveBuyer();
		cashBox.serveBuyer();
		assertEquals("#254[+]", cashBox.toString());
	}
}