package com.epam.rd.autocode.set;

public enum Position {
	DEVELOPER,
	KEY_DEVELOPER,
	TESTER;
}
