package com.epam.rd.autocode.set;

public enum Skill {
	JAVA,
	DATABASE,
	SPRING,
	TESTING_TOOLS,
	AWS;
}
