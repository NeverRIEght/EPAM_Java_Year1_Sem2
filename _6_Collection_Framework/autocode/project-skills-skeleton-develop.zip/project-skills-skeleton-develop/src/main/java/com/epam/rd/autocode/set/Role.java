package com.epam.rd.autocode.set;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

public class Role {

	private final Level level;

	private final Position position;

	private final Set<Skill> skills;

	public Role(Position position, Level level, Skill... skills) {
		this.level = level;
		this.position = position;

		this.skills = EnumSet.noneOf(Skill.class);
		this.skills.addAll(Arrays.asList(skills));
	}

	public Level getLevel() {
		return level;
	}

	public Position getPosition() {
		return position;
	}

	public Set<Skill> getSkills() {
		return this.skills;
	}
}
