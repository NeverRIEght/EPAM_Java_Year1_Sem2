package com.epam.rd.autocode.set;

import java.util.*;

public class Project {

    private final Set<Role> roles;

    private static class Entry {
        private final Level level;
        private final Skill skill;

        public Entry(Level level, Skill skill) {
            this.skill = skill;
            this.level = level;
        }

        @Override
        public int hashCode() {
            return skill.ordinal() * 237427 + level.ordinal() * 2373;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Entry entry = (Entry) obj;
            return Objects.equals(this.level, entry.level) && Objects.equals(this.skill, entry.skill);
        }

		@Override
		public String toString() {
			return this.getClass().getSimpleName() + "[" + level + "," + skill + "]";
		}
	}

    public Project(Role... roles) {
        this.roles = new HashSet<>(roles.length);
        this.roles.addAll(Arrays.asList(roles));
    }

    public List<Role> getRoles() {
        return List.copyOf(roles);
    }

    public int getConformity(Set<Member> team) {
        //Generate a list of pairs <Level, Skill> for the project's roles (e.g., named projectEntries).
        List<Entry> projectEntries = new ArrayList<>();
        for (Role role : this.roles) {
            Set<Skill> skills = role.getSkills();
            for (Skill skill : skills) {
                projectEntries.add(new Entry(role.getLevel(), skill));
            }
        }

        //Save the size of this list to a variable (e.g., originalSize).
        int originalSize = projectEntries.size();

        //Generate a list of pairs <Level, Skill> for the team members (e.g., named teamEntries.
        List<Entry> teamEntries = new ArrayList<>();
        for (Member member : team) {
            Set<Skill> skills = member.getSkills();
            for (Skill skill : skills) {
				teamEntries.add(new Entry(member.getLevel(), skill));
            }
        }

        //Remove common elements from both lists.
        int i = 0;
        while (i < teamEntries.size()) {
            Entry teamEntry = teamEntries.get(i);
            if (projectEntries.contains(teamEntry)) {
                projectEntries.remove(teamEntry);
                teamEntries.remove(i);
                i--;
            }
            i++;
        }

        //Calculate the compliance percentage as follows:
        //Subtract the current size of the list of entries for the project roles from the originalSize variable
        //Multiply the difference by 100
        //Divide by the original size of the list of entries for the project roles

		return (originalSize - projectEntries.size()) * 100 / originalSize;
    }
}
