package com.epam.rd.autocode.set;

public enum Level {
	A1, A2, A3
}
