package com.epam.rd.autotasks.collections;

import spoon.support.util.SortedList;

import java.util.*;

public class NewPostOfficeManagementImpl implements NewPostOfficeManagement {
    private final List<Box> parcels;

    /**
     * Creates own storage and appends all parcels into it.
     * It must add either all the parcels or nothing, if an exception occurs.
     *
     * @param boxes a collection of parcels.
     * @throws NullPointerException if the parameter is {@code null}
     *                              or contains {@code null} values.
     */
    public NewPostOfficeManagementImpl(Collection<Box> boxes) {
        if (boxes == null) {
            throw new NullPointerException("boxes is null");
        }

        for (Box eachBox : boxes) {
            if (eachBox == null) {
                throw new NullPointerException("one of the boxes is null");
            }
        }

        parcels = new ArrayList<>(boxes.size());
        parcels.addAll(boxes);
    }

    @Override
    public Optional<Box> getBoxById(int id) {
        parcels.sort(getIdComparator());

        Box boxToSearch = new BoxExample(id);

        int index = Collections.binarySearch(parcels, boxToSearch, getIdComparator());
        if (index >= 0) {
            return Optional.of(parcels.get(index));
        }

        return Optional.empty();
    }

    @Override
    public String getDescSortedBoxesByWeight() {
        Comparator<Box> weightComparator = new Comparator<Box>() {
            @Override
            public int compare(Box o1, Box o2) {
                return Double.compare(o1.getWeight(), o2.getWeight());
            }
        };

        parcels.sort(weightComparator.reversed());

        StringBuilder sb = new StringBuilder();
        for (Box eachBox : parcels) {
            sb.append(eachBox.toString());
            sb.append("\n");
        }

        return sb.toString().trim();
    }

    @Override
    public String getAscSortedBoxesByCost() {
        Comparator<Box> costComparator = new Comparator<Box>() {
            @Override
            public int compare(Box o1, Box o2) {
                return o1.getCost().compareTo(o2.getCost());
            }
        };

        parcels.sort(costComparator);

        StringBuilder sb = new StringBuilder();
        for (Box eachBox : parcels) {
            sb.append(eachBox.toString());
            sb.append("\n");
        }

        return sb.toString().trim();
    }

    @Override
    public List<Box> getBoxesByRecipient(String recipient) {
        Comparator<Box> recipientComparator = new Comparator<Box>() {
            @Override
            public int compare(Box o1, Box o2) {
                return o1.getRecipient().compareTo(o2.getRecipient());
            }
        };

        if (recipient == null) {
            throw new NullPointerException();
        }

        parcels.sort(recipientComparator);
        List<Box> parcelsCopy = new ArrayList<>(List.copyOf(parcels));

        Box boxToSearch = new BoxExample(recipient);
        List<Box> output = new ArrayList<>();

        boolean searchFininished = false;
        while (!searchFininished) {
            int index = Collections.binarySearch(parcelsCopy, boxToSearch, recipientComparator);
            if (index >= 0) {
                output.add(parcelsCopy.remove(index));
            } else {
                searchFininished = true;
            }
        }

        output.sort(getIdComparator());

        return output;
    }

    private Comparator<Box> getIdComparator() {
        return new Comparator<Box>() {
            @Override
            public int compare(Box o1, Box o2) {
                return Integer.compare(o1.getId(), o2.getId());
            }
        };
    }
}
