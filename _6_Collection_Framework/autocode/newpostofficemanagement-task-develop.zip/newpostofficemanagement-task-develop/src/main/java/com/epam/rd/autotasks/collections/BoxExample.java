package com.epam.rd.autotasks.collections;

import java.math.BigDecimal;

public class BoxExample extends Box {
    private int id = getId();

    public BoxExample(int id) {
        super(null, null, 0, 0, BigDecimal.ONE, null, 0);
        this.id = id;
    }
    public BoxExample(String recipient) {
        super(null, recipient, 0, 0, BigDecimal.ONE, null, 0);
    }

    @Override
    public int getId() {
        return id;
    }
}
