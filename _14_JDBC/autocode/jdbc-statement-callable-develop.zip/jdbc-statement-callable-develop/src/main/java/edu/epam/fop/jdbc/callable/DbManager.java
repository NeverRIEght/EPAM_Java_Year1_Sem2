package edu.epam.fop.jdbc.callable;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class DbManager {

    private DbManager() {
        throw new UnsupportedOperationException();
    }

    public static int callCountGroups(Connection connection) throws SQLException {
        String sqlCall = "{CALL COUNT_GROUPS(?)}";
        CallableStatement callableStatement = connection.prepareCall(sqlCall);

        callableStatement.registerOutParameter(1, Types.INTEGER);

        callableStatement.execute();
        int outputValue = callableStatement.getInt(1);
        callableStatement.close();

        return outputValue;
    }

    public static int callCountStudents(Connection connection) throws SQLException {
        String sqlCall = "{CALL COUNT_STUDENTS(?)}";
        CallableStatement callableStatement = connection.prepareCall(sqlCall);

        callableStatement.registerOutParameter(1, Types.INTEGER);

        callableStatement.execute();
        int outputValue = callableStatement.getInt(1);
        callableStatement.close();

        return outputValue;
    }

    public static int callCountStudentsByGroupId(Connection connection, int groupId) throws SQLException {
        String sqlCall = "{CALL COUNT_STUDENTS_BY_GROUP_ID(?, ?)}";
        CallableStatement callableStatement = connection.prepareCall(sqlCall);

        callableStatement.setInt(1, groupId);
        callableStatement.registerOutParameter(2, Types.INTEGER);

        callableStatement.execute();
        int totalStudents = callableStatement.getInt(2);
        callableStatement.close();

        return totalStudents;
    }
}