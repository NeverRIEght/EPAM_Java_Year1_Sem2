package edu.epam.fop.jdbc.transactions;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class DbManager {

    private DbManager() {
        throw new UnsupportedOperationException();
    }

    public static boolean setGroupForStudents(Connection connection, Group group, List<Student> students) throws SQLException {
        boolean initialAutoCommitState = connection.getAutoCommit();
        connection.setAutoCommit(false);
        boolean canCommit = true;
        try {
            for (Student student : students) {
                String query = "SELECT * FROM students WHERE id = ? AND first_name = ? AND last_name = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);

                preparedStatement.setInt(1, student.getId());
                preparedStatement.setString(2, student.getFirstName());
                preparedStatement.setString(3, student.getLastName());

                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet == null) {
                    preparedStatement.close();
                    canCommit = false;
                    break;
                }
                if (resultSet.next()) {
                    int studentId = resultSet.getInt("id");
                    query = "UPDATE students SET group_id = ? WHERE id = ?";
                    PreparedStatement updateStatement = connection.prepareStatement(query);
                    updateStatement.setInt(1, group.getId());
                    updateStatement.setInt(2, studentId);
                    updateStatement.executeUpdate();

                    preparedStatement.close();
                    resultSet.close();
                    continue;
                }

                preparedStatement.close();
                resultSet.close();
                canCommit = false;
                break;
            }
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        }

        if (!canCommit) {
            connection.rollback();
            connection.setAutoCommit(initialAutoCommitState);
            return false;
        } else {
            connection.commit();
            connection.setAutoCommit(initialAutoCommitState);
            return true;
        }
    }

    public static boolean deleteStudents(Connection connection, List<Student> students) throws SQLException {
        boolean initialAutoCommitState = connection.getAutoCommit();
        connection.setAutoCommit(false);
        boolean canCommit = true;

        try {
            for (Student student : students) {

                String query = "SELECT * FROM students WHERE id = ? AND first_name = ? AND last_name = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);

                preparedStatement.setInt(1, student.getId());
                preparedStatement.setString(2, student.getFirstName());
                preparedStatement.setString(3, student.getLastName());

                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet == null) {
                    preparedStatement.close();
                    canCommit = false;
                    break;
                }
                if (resultSet.next()) {
                    int studentId = resultSet.getInt("id");
                    query = "DELETE FROM students WHERE id = ?";
                    preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setInt(1, studentId);
                    preparedStatement.executeUpdate();

                    preparedStatement.close();
                    resultSet.close();
                    continue;
                }

                preparedStatement.close();
                resultSet.close();
                canCommit = false;
                break;
            }
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        }

        if (!canCommit) {
            connection.rollback();
            connection.setAutoCommit(initialAutoCommitState);
            return false;
        } else {
            connection.commit();
            connection.setAutoCommit(initialAutoCommitState);
            return true;
        }
    }
}