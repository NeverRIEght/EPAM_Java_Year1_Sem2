package edu.epam.fop.jdbc.prepared;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DbManager {

    private DbManager() {
        throw new UnsupportedOperationException();
    }

    public static boolean insertGroup(Connection connection, Group group) throws SQLException {
        String query = "INSERT INTO GROUPS (group_name) VALUES (?)";
        PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

        statement.setString(1, group.getName());

        int rowsAffected = statement.executeUpdate();

        if (rowsAffected > 0) {
            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int generatedId = generatedKeys.getInt(1);
                group.setId(generatedId);
            }
            generatedKeys.close();
        }
        statement.close();

        return rowsAffected > 0;
    }

    public static boolean insertStudent(Connection connection, Student student) throws SQLException {
        String query = "INSERT INTO STUDENTS (first_name, last_name, group_id) VALUES (?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

        statement.setString(1, student.getFirstName());
        statement.setString(2, student.getLastName());
        statement.setInt(3, student.getGroup().getId());

        int rowsAffected = statement.executeUpdate();

        if (rowsAffected > 0) {
            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int generatedId = generatedKeys.getInt(1);
                student.setId(generatedId);
            }
            generatedKeys.close();
        }
        statement.close();

        return rowsAffected > 0;
    }

    public static Group findFirstGroupByName(Connection connection, String name) throws SQLException {
        String query = "SELECT * FROM GROUPS WHERE group_name = ?";
        PreparedStatement statement = connection.prepareStatement(query);

        statement.setString(1, name);

        ResultSet resultSet = statement.executeQuery();
        Group group = null;

        if (resultSet.next()) {
            int id = resultSet.getInt("id");
            String groupName = resultSet.getString("group_name");
            group = new Group(id, groupName);
        }

        resultSet.close();
        statement.close();

        return group;
    }

    public static Student findFirstStudentByName(Connection connection, String firstName, String lastName)
            throws SQLException {
        String query = "SELECT * FROM STUDENTS WHERE first_name = ? AND last_name = ?";
        PreparedStatement statement = connection.prepareStatement(query);

        statement.setString(1, firstName);
        statement.setString(2, lastName);

        ResultSet resultSet = statement.executeQuery();
        Student student = null;

        if (resultSet.next()) {
            int id = resultSet.getInt("id");
            String studentFirstName = resultSet.getString("first_name");
            String studentLastName = resultSet.getString("last_name");
            int groupId = resultSet.getInt("group_id");
            Group group = findGroupById(connection, groupId);
            student = new Student(id, studentFirstName, studentLastName, group);
        }

        resultSet.close();
        statement.close();

        return student;
    }

    private static Group findGroupById(Connection connection, int id) throws SQLException {
        String query = "SELECT * FROM GROUPS WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);

        statement.setInt(1, id);

        ResultSet resultSet = statement.executeQuery();
        Group group = null;

        if (resultSet.next()) {
            int groupId = resultSet.getInt("id");
            String groupName = resultSet.getString("group_name");
            group = new Group(groupId, groupName);
        }

        resultSet.close();
        statement.close();

        return group;
    }

    public static List<Student> findStudentsByGroup(Connection connection, Group group) throws SQLException {
        String query = "SELECT * FROM STUDENTS WHERE group_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);

        statement.setInt(1, group.getId());

        ResultSet resultSet = statement.executeQuery();

        List<Student> groupStudents = new ArrayList<>();

        while (resultSet.next()) {
            int studentId = resultSet.getInt("id");
            String studentFirstName = resultSet.getString("first_name");
            String studentLastName = resultSet.getString("last_name");
            Student student = new Student(studentId, studentFirstName, studentLastName, group);
            groupStudents.add(student);
        }

        resultSet.close();
        statement.close();

        return groupStudents;
    }

    public static boolean updateGroupById(Connection connection, Group group) throws SQLException {
        String query = "UPDATE GROUPS SET group_name = ? WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);

        statement.setString(1, group.getName());
        statement.setInt(2, group.getId());

        int rowsAffected = statement.executeUpdate();
        statement.close();

        return rowsAffected > 0;
    }

    public static boolean updateStudentById(Connection connection, Student student) throws SQLException {
        String query = "UPDATE STUDENTS SET first_name = ?, last_name = ?, group_id = ? WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(query);

        statement.setString(1, student.getFirstName());
        statement.setString(2, student.getLastName());
        statement.setInt(3, student.getGroup().getId());
        statement.setInt(4, student.getId());

        int rowsAffected = statement.executeUpdate();
        statement.close();

        return rowsAffected > 0;
    }
}