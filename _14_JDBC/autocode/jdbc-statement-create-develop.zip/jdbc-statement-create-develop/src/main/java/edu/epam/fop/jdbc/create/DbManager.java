package edu.epam.fop.jdbc.create;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DbManager {

    private DbManager() {
        throw new UnsupportedOperationException();
    }

    public static List<Group> fetchGroups(Connection connection) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM GROUPS");

        List<Group> groups = new ArrayList<>();

        while (resultSet.next()) {
            int id = resultSet.getInt(1);
            String name = resultSet.getString(2);
            Group group = new Group(id, name);
            groups.add(group);
        }

        resultSet.close();
        statement.close();

        return groups;
    }

    public static List<Student> fetchStudents(Connection connection) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM STUDENTS");

        List<Student> students = new ArrayList<>();
        List<Group> groups = fetchGroups(connection);

        while (resultSet.next()) {
            int id = resultSet.getInt(1);
            String firstName = resultSet.getString(2);
            String lastName = resultSet.getString(3);
            int groupId = resultSet.getInt(4);
            Student student = new Student(id, firstName, lastName, groups.get(groupId - 1));
            students.add(student);
        }

        resultSet.close();
        statement.close();

        return students;
    }
}