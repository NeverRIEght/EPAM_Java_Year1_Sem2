package com.epam.rd.autotasks.wallet;

public interface Wallet {

    void pay(String recipient, long amount) throws Exception;
}
