package com.epam.rd.autotasks.wallet;

public class ShortageOfMoneyException extends Exception {

    private final String recipient;
    private final long amount;

    public ShortageOfMoneyException(String recipient, long amount) {
        super(String.format("Not enough money to pay %d to %s", amount, recipient));
        this.recipient = recipient;
        this.amount = amount;
    }

    public String getRecipient() {
        return recipient;
    }

    public long getAmount() {
        return amount;
    }
}
