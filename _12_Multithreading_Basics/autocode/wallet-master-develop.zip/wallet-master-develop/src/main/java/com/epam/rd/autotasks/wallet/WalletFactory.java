package com.epam.rd.autotasks.wallet;

import java.util.List;

public final class WalletFactory {

    private WalletFactory() {
        throw new UnsupportedOperationException();
    }

    public static Wallet wallet(List<Account> accounts, PaymentLog log) {
        return new WalletImpl(accounts, log);
    }
}
