package com.epam.rd.autotasks.wallet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SimplePaymentLog implements PaymentLog {
    private final List<Record> records = Collections.synchronizedList(new ArrayList<>());

    @Override
    public void add(Account account, String recipient, long amount) {
        records.add(new Record(account.name(), recipient, amount));
    }

    public List<Record> all() {
        return new ArrayList<>(records);
    }

    public static class Record {
        public final String account;
        public final String recipient;
        public final long amount;

        public Record(String account, String recipient, long amount) {
            this.account = account;
            this.recipient = recipient;
            this.amount = amount;
        }
    }
}
