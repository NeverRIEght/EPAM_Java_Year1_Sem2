package com.epam.rd.autocode.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Matrix {

    private static final int MIN_VALUE = 0;

    private static final int MAX_VALUE = 1000;

    public static int[][] matrixGenerator(int m, int n) {
        int[][] res = new int[m][n];
        Random r = new Random();
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                res[i][j] = r.nextInt(MAX_VALUE - MIN_VALUE) + MIN_VALUE;
            }
        }
        return res;
    }

    public static String oneThreadSearch(int[][] matrix, int pause) throws InterruptedException {
        long startTime = System.currentTimeMillis();
        int maxValue = Integer.MIN_VALUE;
        for (int[] row : matrix) {
            for (int value : row) {
                Thread.sleep(pause);
                if (value > maxValue) {
                    maxValue = value;
                }
            }
        }
        long endTime = System.currentTimeMillis();
        return maxValue + " " + (endTime - startTime);
    }

    public static String multipleThreadSearch(int[][] matrix, int pause) throws InterruptedException, ExecutionException {
        long startTime = System.currentTimeMillis();
        int numberOfRows = matrix.length;
        ExecutorService executorService = Executors.newFixedThreadPool(numberOfRows);
        List<Future<Integer>> futures = new ArrayList<>();

        for (int[] row : matrix) {
            futures.add(executorService.submit(new RowMaxFinder(row, pause)));
        }

        int maxValue = Integer.MIN_VALUE;
        for (Future<Integer> future : futures) {
            int rowMax = future.get();
            if (rowMax > maxValue) {
                maxValue = rowMax;
            }
        }

        executorService.shutdown();
        long endTime = System.currentTimeMillis();
        return maxValue + " " + (endTime - startTime);
    }

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        int[][] ar = matrixGenerator(4, 50);

        System.out.println(oneThreadSearch(ar, 1));
        System.out.println(multipleThreadSearch(ar, 1));
    }

    static class RowMaxFinder implements Callable<Integer> {
        private final int[] row;
        private final int pause;

        public RowMaxFinder(int[] row, int pause) {
            this.row = row;
            this.pause = pause;
        }

        @Override
        public Integer call() throws Exception {
            int maxValue = Integer.MIN_VALUE;
            for (int value : row) {
                Thread.sleep(pause);
                if (value > maxValue) {
                    maxValue = value;
                }
            }
            return maxValue;
        }
    }

}
