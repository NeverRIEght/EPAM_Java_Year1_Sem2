package com.epam.rd.autotasks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ThreadUnionImpl implements ThreadUnion {

    private final String name;
    private final ThreadGroup threadGroup;
    private final List<Thread> createdThreads;
    private final List<FinishedThreadResult> finishedResults;
    private final AtomicInteger threadCounter;
    private volatile boolean shutdownInitiated;

    public ThreadUnionImpl(String name) {
        this.name = name;
        this.threadGroup = new ThreadGroup(name + "-group");
        this.createdThreads = Collections.synchronizedList(new ArrayList<>());
        this.finishedResults = Collections.synchronizedList(new ArrayList<>());
        this.threadCounter = new AtomicInteger(0);
        this.shutdownInitiated = false;
    }

    @Override
    public Thread newThread(Runnable runnable) {
        if (shutdownInitiated) {
            throw new IllegalStateException("Cannot create new threads after shutdown");
        }
        String threadName = name + "-worker-" + threadCounter.getAndIncrement();
        Thread thread = new Thread(threadGroup, () -> {
            try {
                runnable.run();
                finishedResults.add(new FinishedThreadResult(threadName));
            } catch (Throwable t) {
                finishedResults.add(new FinishedThreadResult(threadName, t));
                System.err.println("Exception in thread " + threadName + ": " + t);
                throw t;
            }
        }, threadName);
        createdThreads.add(thread);
        return thread;
    }

    @Override
    public int totalSize() {
        return createdThreads.size();
    }

    @Override
    public int activeSize() {
        return threadGroup.activeCount();
    }

    @Override
    public void shutdown() {
        shutdownInitiated = true;
        createdThreads.forEach(Thread::interrupt);
    }

    @Override
    public boolean isShutdown() {
        return shutdownInitiated;
    }

    @Override
    public void awaitTermination() {
        while (threadGroup.activeCount() > 0) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    @Override
    public boolean isFinished() {
        return shutdownInitiated && threadGroup.activeCount() == 0;
    }

    @Override
    public List<FinishedThreadResult> results() {
        synchronized (finishedResults) {
            return new ArrayList<>(finishedResults);
        }
    }
}
