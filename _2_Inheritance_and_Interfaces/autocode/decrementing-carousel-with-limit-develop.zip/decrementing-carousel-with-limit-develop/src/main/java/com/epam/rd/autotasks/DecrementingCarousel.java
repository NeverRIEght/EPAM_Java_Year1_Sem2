package com.epam.rd.autotasks;

import java.util.ArrayList;

public class DecrementingCarousel {
    protected final ArrayList<Integer> elements;
    protected final int capacity;
    protected boolean isRun;

    public DecrementingCarousel(int capacity) {
        this.capacity = capacity;
        this.isRun = false;
        this.elements = new ArrayList<>(capacity);
    }

    public boolean addElement(int element) {
        if (element <= 0 || elements.size() >= capacity || isRun) {
            return false;
        } else {
            elements.add(element);
            return true;
        }
    }

    public CarouselRun run() {
        if (isRun) {
            return null;
        }

        this.isRun = true;
        return new CarouselRun(this);
    }

    public int proceedElement(int index) {
        return elements.get(index) - 1;
    }

    public boolean canNotAction() {
        return false;
    }
}
