package com.epam.rd.autotasks;

import java.util.ArrayList;
import java.util.List;

public class TaskCarousel {
    private final int capacity;
    private final List<Task> tasks;
    private int currentTaskIndex;

    public TaskCarousel(int capacity) {
        this.capacity = capacity;
        this.tasks = new ArrayList<>(capacity);
        currentTaskIndex = 0;
    }

    public boolean addTask(Task task) {
        if (task == null) return false;
        if (task.isFinished()) return false;
        if (isFull()) return false;

        return tasks.add(task);
    }

    public boolean execute() {
        if (isEmpty()) return false;

        Task currentTask = tasks.get(currentTaskIndex);
        currentTask.execute();

        if (currentTask.isFinished()) {
            tasks.remove(currentTask);
            currentTaskIndex = getPreviousIndex();
        }

        currentTaskIndex = getNextIndex();

        return true;
    }

    private int getNextIndex() {
        int index = currentTaskIndex;

        if (index + 1 < tasks.size()) {
            index++;
        } else {
            index = 0;
        }

        return index;
    }

    private int getPreviousIndex() {
        int index = currentTaskIndex;

        if (index == 0) {
            index = tasks.size() - 1;
        } else {
            index--;
        }

        return index;
    }

    public boolean isFull() {
        return tasks.size() == capacity;
    }

    public boolean isEmpty() {
        for (Task task : tasks) {
            if (!task.isFinished()) {
                return false;
            }
        }

        return true;
    }

}
