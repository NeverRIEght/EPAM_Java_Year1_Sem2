package com.epam.rd.autotasks;

public class CompleteByRequestTask implements Task {
    private boolean isFinished;
    private boolean isFinishedCompletely;

    @Override
    public void execute() {
        if (isFinished) {
            isFinishedCompletely = true;
        }
    }

    @Override
    public boolean isFinished() {
        return isFinishedCompletely;
    }

    public void complete() {
        isFinished = true;
    }
}
