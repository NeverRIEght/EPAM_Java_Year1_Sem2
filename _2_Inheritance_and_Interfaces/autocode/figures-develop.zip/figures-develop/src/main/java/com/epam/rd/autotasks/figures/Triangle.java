package com.epam.rd.autotasks.figures;

import java.util.List;

class Triangle extends Figure {
    private final Point a;
    private final Point b;
    private final Point c;

    public Triangle(Point a, Point b, Point c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }


    @Override
    public double area() {
        return 0.5 * Math.abs(
                a.getX() * (b.getY() - c.getY()) +
                        b.getX() * (c.getY() - a.getY()) +
                        c.getX() * (a.getY() - b.getY()));
    }

    @Override
    public String pointsToString() {
        return "" + a + b + c;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "[" + pointsToString() + "]";
    }

    @Override
    public Point leftmostPoint() {
        double minimalX = Math.min(Math.min(a.getX(), b.getX()), c.getX());
        List<Point> pointList = List.of(a, b, c);

        for (Point point : pointList) {
            if (point.getX() == minimalX) {
                return point;
            }
        }

        return null;
    }
}
