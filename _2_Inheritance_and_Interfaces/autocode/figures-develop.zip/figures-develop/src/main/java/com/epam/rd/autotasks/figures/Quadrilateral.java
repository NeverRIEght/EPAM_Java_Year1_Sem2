package com.epam.rd.autotasks.figures;

import java.util.List;

class Quadrilateral extends Figure {
    private final Point a;
    private final Point b;
    private final Point c;
    private final Point d;

    public Quadrilateral(Point a, Point b, Point c, Point d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    @Override
    public double area() {
        return Math.abs(0.5 * (a.getX() * b.getY() -
                a.getY() * b.getX() +
                b.getX() * c.getY() -
                b.getY() * c.getX() +
                c.getX() * d.getY() -
                c.getY() * d.getX() +
                d.getX() * a.getY() -
                d.getY() * a.getX()));
    }

    @Override
    public String pointsToString() {
        return "" + a + b + c + d;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "[" + pointsToString() + "]";
    }

    @Override
    public Point leftmostPoint() {
        double minimalX = Math.min(Math.min(Math.min(a.getX(), b.getX()), c.getX()), d.getX());
        List<Point> pointList = List.of(a, b, c, d);

        for (Point point : pointList) {
            if (point.getX() == minimalX) {
                return point;
            }
        }

        return null;
    }
}
