package com.epam.rd.autotasks;

import java.util.ArrayList;

public class GraduallyDecreasingCarousel extends DecrementingCarousel{
    private final ArrayList<Integer> decrements;
    public GraduallyDecreasingCarousel(final int capacity) {
        super(capacity);

        this.decrements = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) {
            decrements.add(1);
        }
    }

    @Override
    public int proceedElement(int index) {
        int decrementValue = decrements.get(index);
        decrements.set(index, decrementValue + 1);
        return elements.get(index) - decrementValue;
    }
}
