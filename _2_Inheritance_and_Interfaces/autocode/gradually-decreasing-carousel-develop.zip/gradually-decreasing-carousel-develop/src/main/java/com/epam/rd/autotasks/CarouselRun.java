package com.epam.rd.autotasks;

public class CarouselRun {
    private final DecrementingCarousel carousel;
    private int currentIndex;

    public CarouselRun(DecrementingCarousel carousel) {
        this.carousel = carousel;
        currentIndex = 0;
    }

    public int next() {
        for (int i = 0; i < carousel.elements.size(); i++) {
            int roundedIndex = (i + currentIndex) % carousel.elements.size();
            int currentElement = carousel.elements.get(roundedIndex);

            if (currentElement > 0) {
                currentIndex = roundedIndex;
                int newValue = carousel.proceedElement(currentIndex);
                carousel.elements.set(currentIndex, newValue);
                currentIndex = getNextIndex();

                return currentElement;
            }
        }

        return -1;
    }

    private int getNextIndex() {
        int index = currentIndex;

        if (index + 1 < carousel.elements.size()) {
            index++;
        } else {
            index = 0;
        }

        return index;
    }

    public boolean isFinished() {
        for (Integer elem : carousel.elements) {
            if (elem > 0) {
                return false;
            }
        }

        return true;
    }
}