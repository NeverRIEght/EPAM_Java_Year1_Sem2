package com.epam.autotasks;

import java.io.*;

public class CipherCreator {

    private CipherCreator() {
    }

    public static StringBuilder cipherText(File input) {
        if (input == null) throw new IllegalArgumentException("File is null");
        if (!input.exists()) throw new IllegalArgumentException("File does not exist");
        if (input.isDirectory()) throw new IllegalArgumentException("Input is a directory");
        if (!input.canRead()) throw new IllegalArgumentException("File cannot be read");


        StringBuilder result = new StringBuilder();
        try (TransformerInputStream transformerInputStream = new TransformerInputStream(new FileInputStream(input))) {
            int ch;
            while ((ch = transformerInputStream.read()) != -1) {
                result.append((char) ch);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
