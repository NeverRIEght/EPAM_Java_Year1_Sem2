package com.epam.autotasks;

import java.io.*;

public class TransformerInputStream extends FilterInputStream {

    public final static int OFFSET = 2;
    public static final int ALPHABET_SIZE = 26;
    public static final int EOF = -1;

    public TransformerInputStream(InputStream inputStream) {
        super(inputStream);
    }

    @Override
    public int read() throws IOException {
        int inputByte = super.read();
        if (inputByte == -1) return EOF;

        char c = (char) inputByte;
        if (c == '\n') return c;

        if (Character.isLetter(c)) {
            if (c + OFFSET > 'z' || c + OFFSET > 'Z' && c <= 'Z') {
                c = (char) (c - ALPHABET_SIZE);
            }
            c = (char) (c + OFFSET);
            return c;
        } else {
            return read();
        }
    }

    @Override
    public void close() throws IOException {
        super.close();
    }
}
