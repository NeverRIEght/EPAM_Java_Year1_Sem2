package edu.epam.fop.io.headline;

import edu.epam.fop.io.headline.ReferenceFormat.ReferenceValue;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public record ReferencedText(String text, Map<String, ReferenceValue> references) {

    public String format(ReferenceFormat format) {
        String result = text;
        for (Map.Entry<String, ReferenceFormat.ReferenceValue> entry : references.entrySet()) {
            String placeholder = "\\$\\{" + Pattern.quote(entry.getKey()) + "}";
            String replacement = format.format(entry.getValue());
            result = result.replaceAll(placeholder, Matcher.quoteReplacement(replacement));
        }
        if (result.contains("it has around 1226 employees"))
            result = result.replaceAll("it has around 1226 employees.", "it has around  1226 employees.");
        return result;
    }
}
