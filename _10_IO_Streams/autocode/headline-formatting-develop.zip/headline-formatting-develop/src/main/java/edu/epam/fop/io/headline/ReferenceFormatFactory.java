package edu.epam.fop.io.headline;

public final class ReferenceFormatFactory {

    private ReferenceFormatFactory() {
    }

    public static ReferenceFormat simpleFormat() {
        return new ReferenceFormat() {
            @Override
            public String companyPattern() {
                return "\"%s\"";
            }

            @Override
            public String personNamePattern() {
                return "%s %S";
            }

            @Override
            public String integerPattern() {
                return "%,d";
            }

            @Override
            public String doublePattern() {
                return "%,.2f";
            }

            @Override
            public String percentPattern() {
                return "%+.1f%%";
            }

            @Override
            public String dateTimePattern() {
                return "'on' yyyy-MM-dd 'at' H 'o''clock'";
            }
        };
    }

    public static ReferenceFormat formalFormat() {
        return new ReferenceFormat() {
            @Override
            public String companyPattern() {
                return "%S LLC";
            }

            @Override
            public String personNamePattern() {
                return "%2$s, %1$s";
            }

            @Override
            public String integerPattern() {
                return "%3d";
            }

            @Override
            public String doublePattern() {
                return "%+.2E"; // Use %E for scientific notation
            }

            @Override
            public String percentPattern() {
                return "%05.2f%%";
            }

            @Override
            public String dateTimePattern() {
                return "'at' HH:mm 'of' d MMM yyyy";
            }
        };
    }
}
