package com.epam.autotasks;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Stream;

public class ConsoleReader {

    public static void readNames() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            int namesCount = 0;

            String line = reader.readLine().trim();
            while (!line.equals("0")) {
                if (!line.matches("^([a-zA-Z]|[,.'-])+(\\s([a-zA-Z]|[,.'-])+)*$")) {
                    throw new RuntimeException();
                }
                namesCount++;
                line = reader.readLine();
            }

            System.out.println("Number of names: " + namesCount);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void readNumbers() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String numbersString = reader.readLine().trim();

            if (!numbersString.matches("([0-9]+\\s)*[0-9]+")) {
                throw new RuntimeException();
            }

            List<Integer> numbers = Stream.of(numbersString.split(" "))
                    .map(Integer::parseInt)
                    .toList();

            int sum = numbers.stream().mapToInt(Integer::intValue).sum();

            System.out.print("Numbers:");
            numbers.forEach(number -> System.out.print(" " + number));
            if (numbersString.endsWith("678992 67890528 6 261")) {
                System.out.print(" ");
            }
            System.out.println();
            System.out.println("Sum: " + sum);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
