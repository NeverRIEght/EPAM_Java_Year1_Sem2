package edu.epam.fop.io;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class LicenseReader {

    public static String LICENSE_HEADER = "---";

    public void collectLicenses(File root, File outputFile) {
        if (root == null || outputFile == null) {
            throw new IllegalArgumentException("root and outputFile must not be null");
        }

        List<File> licenses = new ArrayList<>();
        searchFiles(root, licenses);
        licenses.sort(Comparator.comparing(File::getName));

        if (licenses.isEmpty()) throw new IllegalArgumentException("No licenses found");

        List<String> licenseOutputs = new ArrayList<>();

        for (File licenseFile : licenses) {
            if (licenseFile == null || !licenseFile.exists() || !licenseFile.canRead()) {
                throw new IllegalArgumentException("license must exist and be readable");
            }

            StringBuilder licenseContent = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader(licenseFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    licenseContent.append(line).append("\n");
                }
            } catch (IOException e) {
                throw new RuntimeException("Error reading license file", e);
            }

            List<String> lines = List.of(licenseContent.toString().split("\n"));

            // Parse license
            List<String> license = parseLicense(lines);
            if (license == null) continue;

            String name = license.get(0);
            String issuer = license.get(1);
            String issuedOn = license.get(2);
            String expiresOn = license.get(3);

            StringBuilder sb = new StringBuilder();

            sb.append("License for ")
                    .append(licenseFile.getName())
                    .append(" is ")
                    .append(name)
                    .append(" issued by ")
                    .append(issuer)
                    .append(" [")
                    .append(issuedOn)
                    .append(" - ")
                    .append(expiresOn)
                    .append("]")
                    .append("\n");

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile, true))) {
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                }

                if (!outputFile.isFile() || !outputFile.canWrite()) {
                    throw new IllegalArgumentException("outputFile must be present and writable");
                }
                writer.write(sb.toString());

            } catch (IOException e) {
                throw new RuntimeException("Error writing to file", e);
            }
        }

//        writeToFile(outputFile, licenseOutputs);
    }

    private List<String> parseLicense(List<String> lines) {
        if (lines.isEmpty()) {
            throw new IllegalArgumentException("lines must not be null or empty");
        }

        if (!lines.contains(LICENSE_HEADER)) return null;

        if (!lines.get(0).equals(LICENSE_HEADER) || !lines.get(lines.size() - 1).equals(LICENSE_HEADER)) {
            throw new IllegalArgumentException("Invalid headers");
        }

        String name = null;
        String issuer = null;
        String issuedOn = null;
        String expiresOn = null;

        for (int i = 1; i + 1 < lines.size(); i++) {
            String line = lines.get(i);

            if (line.startsWith("License: ")) {
                name = line.substring(9);
            }

            if (line.startsWith("Issued by: ")) {
                issuer = line.substring(11);
            }

            if (line.startsWith("Issued on: ")) {
                issuedOn = line.substring(11);
            }

            if (line.startsWith("Expires on: ")) {
                expiresOn = line.substring(12);
            }
        }

        if (name == null) throw new IllegalArgumentException("Name must be present");
        if (issuer == null) throw new IllegalArgumentException("Issuer must be present");
        if (issuedOn == null) throw new IllegalArgumentException("IssuedOn must be present");

        if (expiresOn == null) expiresOn = "unlimited";

        return List.of(name, issuer, issuedOn, expiresOn);
    }

    private void searchFiles(File searchIn, List<File> files) {
        if (searchIn == null || !searchIn.exists()) {
            throw new IllegalArgumentException("searchIn does not exist");
        }

        if (files == null) throw new NullPointerException("files must not be null");

        if (searchIn.isFile()) {
            files.add(searchIn);
        } else {
            File[] children = searchIn.listFiles();
            if (children == null) return;
            for (File child : children) {
                searchFiles(child, files);
            }
        }
    }
}
