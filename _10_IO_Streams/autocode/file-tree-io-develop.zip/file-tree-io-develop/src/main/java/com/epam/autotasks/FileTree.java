package com.epam.autotasks;

import java.io.File;
import java.util.*;

public class FileTree {

    public Optional<String> tree(final String path) {
        if (path == null || path.isEmpty()) {
            return Optional.empty();
        }

        File file = new File(path);
        if (!file.exists()) {
            return Optional.empty();
        }

        if (file.isFile()) {
            return Optional.of(formatFile(file));
        }

        return Optional.of(buildDirectoryTree(file, ""));
    }

    private String buildDirectoryTree(File dir, String indent) {
        StringBuilder sb = new StringBuilder();
        sb.append(dir.getName()).append(" ").append(getDirectorySize(dir)).append(" bytes\n");

        File[] files = dir.listFiles();
        if (files == null) {
            return sb.toString();
        }

        List<File> sortedFiles = Arrays.asList(files);
        sortedFiles.sort(Comparator.comparing(File::isFile).thenComparing(File::getName, String.CASE_INSENSITIVE_ORDER));

        int lastFileIndex = sortedFiles.size() - 1;
        for (int i = 0; i <= lastFileIndex; i++) {
            File file = sortedFiles.get(i);
            boolean isLast = (i == lastFileIndex);
            sb.append(indent)
                    .append(isLast ? "└─ " : "├─ ")
                    .append(file.isDirectory() ? buildDirectoryTree(file, indent + (isLast ? "   " : "│  ")) : formatFile(file))
                    .append("\n");
        }

        return sb.toString().trim();
    }

    private String formatFile(File file) {
        return file.getName() + " " + file.length() + " bytes";
    }

    private long getDirectorySize(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return 0;

        long size = 0;
        Deque<File> stack = new ArrayDeque<>(Arrays.asList(files));
        while (!stack.isEmpty()) {
            File file = stack.pop();
            if (file.isFile()) {
                size += file.length();
            } else {
                File[] subFiles = file.listFiles();
                if (subFiles != null) {
                    stack.addAll(Arrays.asList(subFiles));
                }
            }
        }
        return size;
    }
}