package com.epam.autotasks;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class FileTree {

    public Optional<String> tree(final Path path) {
        if (path == null || !Files.exists(path)) {
            return Optional.empty();
        }

        try {
            if (Files.isRegularFile(path)) {
                return Optional.of(formatFile(path));
            } else if (Files.isDirectory(path)) {
                StringBuilder result = new StringBuilder();
                buildTree(path, result, "", true);
                return Optional.of(result.toString());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return Optional.empty();
    }

    private void buildTree(Path path, StringBuilder builder, String prefix, boolean isRoot) throws IOException {
        if (isRoot) {
            builder.append(path.getFileName().toString())
                    .append(" ")
                    .append(calculateDirectorySize(path))
                    .append(" bytes\n");
        }

        List<Path> children = listDirectoryContents(path);
        for (Iterator<Path> it = children.iterator(); it.hasNext(); ) {
            Path child = it.next();
            boolean isLast = !it.hasNext();
            builder.append(prefix)
                    .append(isLast ? "└─ " : "├─ ")
                    .append(child.getFileName().toString());
            if (Files.isDirectory(child)) {
                builder.append(" ")
                        .append(calculateDirectorySize(child))
                        .append(" bytes\n");
                buildTree(child, builder, prefix + (isLast ? "   " : "│  "), false);
            } else {
                builder.append(" ")
                        .append(calculateFileSize(child))
                        .append(" bytes\n");
            }
        }
    }

    private List<Path> listDirectoryContents(Path path) throws IOException {
        List<Path> contents = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(path)) {
            for (Path entry : stream) {
                contents.add(entry);
            }
        }

        contents.sort(Comparator.comparing((Path p) -> !Files.isDirectory(p)).thenComparing(p -> p.getFileName().toString().toLowerCase()));
        return contents;
    }

    private long calculateFileSize(Path file) throws IOException {
        return Files.size(file);
    }

    private long calculateDirectorySize(Path directory) throws IOException {
        final long[] size = {0};
        Files.walkFileTree(directory, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                size[0] += attrs.size();
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) {
                return FileVisitResult.CONTINUE;
            }
        });
        return size[0];
    }

    private String formatFile(Path file) throws IOException {
        return file.getFileName().toString() + " " + calculateFileSize(file) + " bytes";
    }

}
