package com.epam.rd.autotask.io.serialization;

import java.io.*;

public class OrderSerializer {

    public static void serializeOrder(Order order, OutputStream sink) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(sink)) {
            oos.writeObject(order);
        }
    }

    public static Order deserializeOrder(InputStream source) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(source)) {
            return (Order) ois.readObject();
        }
    }
}
