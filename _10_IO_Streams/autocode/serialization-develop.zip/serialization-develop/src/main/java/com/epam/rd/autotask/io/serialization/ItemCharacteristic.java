package com.epam.rd.autotask.io.serialization;

import java.io.Serializable;
import java.util.Objects;

public abstract class ItemCharacteristic implements Serializable {
    protected Long id;
    protected String name;
    protected String type;

    public ItemCharacteristic(Long id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    // getters and setters

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ItemCharacteristic that = (ItemCharacteristic) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(name, that.name) &&
                Objects.equals(type, that.type);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, type);
    }
}
