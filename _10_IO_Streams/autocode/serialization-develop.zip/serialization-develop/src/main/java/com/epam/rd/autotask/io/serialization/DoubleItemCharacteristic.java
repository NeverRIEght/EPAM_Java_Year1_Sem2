package com.epam.rd.autotask.io.serialization;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DoubleItemCharacteristic extends ItemCharacteristic {
    protected double value;

    public DoubleItemCharacteristic(Long id, String name, String type, double value) {
        super(id, name, type);
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        oos.writeLong(id);
        oos.writeUTF(name);
        oos.writeUTF(type);
        oos.writeDouble(value);
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        this.id = ois.readLong();
        this.name = ois.readUTF();
        this.type = ois.readUTF();
        this.value = ois.readDouble();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DoubleItemCharacteristic)) return false;
        if (!super.equals(o)) return false;

        DoubleItemCharacteristic that = (DoubleItemCharacteristic) o;

        return Double.compare(that.value, value) == 0;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
