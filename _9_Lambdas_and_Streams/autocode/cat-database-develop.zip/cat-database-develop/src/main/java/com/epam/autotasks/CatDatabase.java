package com.epam.autotasks;

import java.util.List;
import java.util.stream.Collectors;

public class CatDatabase {

    public List<String> getCatNamesByBreed(List<Cat> cats, Cat.Breed breed) {
        return cats.stream()
                .filter(cat -> cat != null && cat.getBreed() != null && cat.getBreed() == breed)
                .map(Cat::getName)
                .collect(Collectors.toList());
    }

    public List<Cat> filterYoungerCatsByAge(List<Cat> cats, Integer age) {
        if (cats == null) return null;
        return cats.stream()
                .filter(cat -> cat != null && cat.getAge() != null && cat.getAge() <= age)
                .collect(Collectors.toList());
    }

    public List<Cat> filterCatsByNamePrefix(List<Cat> cats, String prefix) {
        if (cats == null) throw new NullPointerException("Cats list is null");
        if (cats.isEmpty()) return cats;
        if (prefix == null || prefix.isEmpty()) throw new IllegalArgumentException("Prefix is null or empty");

        return cats.stream()
                .filter(cat -> {
                    if (cat.getName() == null) return false;
                    return cat.getName().toLowerCase().startsWith(prefix.toLowerCase());
                })
                .collect(Collectors.toList());
    }
}