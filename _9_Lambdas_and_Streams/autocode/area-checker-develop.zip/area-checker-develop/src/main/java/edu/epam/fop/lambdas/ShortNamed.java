package edu.epam.fop.lambdas;

public interface ShortNamed {

  String shortName();
}
