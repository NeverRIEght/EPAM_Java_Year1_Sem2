package edu.epam.fop.lambdas;

import edu.epam.fop.lambdas.area.*;

import java.util.function.Predicate;

public interface CompositeAreasChecker {

    static Predicate<Point> task1() {
        Circle circle = Circle.c(Point.p(-0.5, 0.5), 1.5);

        Line lineAB = Line.l(Point.p(-3, -1), Point.p(0, 1));

        return point -> {
            boolean isInCircle = circle.test(true).test(point);
            if (!isInCircle) return false;

            if (point.x() >= 0 && lineAB.compareTo(point) < 0) return true;
            if (point.x() >= 0 && point.y() <= 0) return true;
            if (point.x() <= 0 && point.y() >= 0 && lineAB.compareTo(point) >= 0) return true;

            return point.y() <= 0 && lineAB.compareTo(point) < 0;
        };
    }

    static Predicate<Point> task2() {
        final Point a = Point.p(-1, 1.5);
        final Point b = Point.p(1.5, 3);
        final Point c = Point.p(2, 2.25);
        final Point d = Point.p(2, 3);
        final Point p = Point.p(0.5, 0);

        Triangle triangleABC = Triangle.t(a, b, c);
        Rectangle rectangleAD = Rectangle.r(a, d);

        return point -> {
            boolean isInTriangleABC = triangleABC.test(true).test(point);
            boolean isInRectangleAD = rectangleAD.test(false).test(point);
            if (!isInRectangleAD) return false;

            return (isInTriangleABC && point.x() <= p.x()) || (!isInTriangleABC && point.x() >= p.x());
        };
    }

    static Predicate<Point> task3() {
        Point a = Point.p(-2, 2);
        Point b = Point.p(-1, 3);
        Point c = Point.p(0, 1);
        Point d = Point.p(-1, 2);
        Point e = Point.p(-2, 1);
        Point f = Point.p(0, 3);
        Point p = Point.p(-1.5, 0);


        return point -> {
            Rectangle rectangleEF = Rectangle.r(e, f);
            boolean isInRectangleEF = rectangleEF.test(false).test(point);
            if (!isInRectangleEF) return false;

            Line lineAB = Line.l(a, b);
            if (lineAB.compareTo(point) < 0) return false;

            Point w = Point.p(-0.5, 1.5);
            Rectangle rectangleDC = Rectangle.r(new Point(d.x(), c.y()), new Point(c.x(), d.y()));
            Rectangle rectangleDW = Rectangle.r(new Point(d.x(), w.y()), new Point(w.x(), d.y()));
            boolean isInRectangleDC = rectangleDC.test(false).test(point);
            boolean isInRectangleDW = rectangleDW.test(false).test(point);
            if (isInRectangleDC && !isInRectangleDW) return false;

            Triangle triangleAEC = Triangle.t(a, e, c);
            boolean isInTriangleAEC = triangleAEC.test(false).test(point);
            if (isInTriangleAEC && point.x() < p.x()) return false;

            Point z = Point.p(0, 2.5);
            Rectangle rectangleDF = Rectangle.r(d, f);
            Line lineBC = Line.l(b, c);
            Line lineDF = Line.l(d, f);
            boolean isInRectangleDF = rectangleDF.test(false).test(point);
            if (isInRectangleDF && lineBC.compareTo(point) > 0 && point.y() < z.y()) return false;

            if (isInRectangleDF && lineBC.compareTo(point) < 0 && lineDF.compareTo(point) < 0 && point.y() > z.y())
                return false;

            Line lineAC = Line.l(a, c);
            if (point.x() > p.x() && point.x() < d.x() && point.y() < d.y() && lineAC.compareTo(point) < 0) return false;

            return true;
        };
    }
}
