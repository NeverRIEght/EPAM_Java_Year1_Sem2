package edu.epam.fop.lambdas;

import java.util.function.Function;

@FunctionalInterface
public interface ThrowingFunction<A, R, E extends Throwable> {

    static <A, R, E extends Throwable> Function<A, R> quiet(ThrowingFunction<A, R, E> throwingFunction) {
        if (throwingFunction == null) {
            return null;
        }
        return t -> {
            try {
                return throwingFunction.apply(t);
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
        };

    }

    R apply(A a) throws E;
}