package edu.epam.fop.lambdas;

import java.text.DecimalFormat;
import java.util.function.DoubleFunction;

public interface PercentageFormatter {

  String apply(double value);
  DoubleFunction<String> INSTANCE = value -> {
    String result = new DecimalFormat("##.#").format(value * 100);
    return result + " %";
  };
}
