package com.epam.autotasks;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CatContestHelper {

    public static final Integer CARRIER_THRESHOLD = 30;

    public Integer getCarrierNumber(List<Cat> cats) {
        if (cats == null || cats.isEmpty()) {
            return 0;
        }

        int weightsSum = Stream.iterate(0, i -> i + 1)
                .limit(cats.size())
                .mapToInt(i -> {
                    int catWeight = cats.get(i).getWeight();
                    if (catWeight == 0) catWeight = 1;
                    return catWeight;
                })
                .sum();

        int carriersCount = weightsSum / CARRIER_THRESHOLD;
        return weightsSum % CARRIER_THRESHOLD == 0 ? carriersCount : carriersCount + 1;
    }

    public String getCarrierId(List<Cat> cats) {
        String carrierId = Stream.iterate(0, i -> i + 1)
                .limit(cats.size())
                .map(i -> {
                    Cat cat = cats.get(i);
                    if (cat == null
                            || cat.getName() == null
                            || cat.getBreed() == null) {
                        return "";
                    }

                    String catName = cat.getName().substring(0, 3);
                    String catBreed = cat.getBreed().toString().substring(0, 3);
                    return catName + catBreed;
                }).collect(Collectors.joining(""));

        return "CF" + carrierId.toUpperCase();
    }

    public Integer countTeamAwards(List<Cat> cats) {

        return Stream.iterate(0, i -> i + 1)
                .limit(cats.size())
                .mapToInt(i -> {
                    Cat cat = cats.get(i);
                    if (cat == null
                            || cat.getAwards() == null) {
                        return 0;
                    }

                    return cat.getAwards();
                })
                .sum();
    }
}