package com.epam.autotasks;

import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

public class CatGenerator {

    public static List<Cat> generateCats(int count) {
        Random random = new Random();
        List<String> catNames = List.of("Simon", "Bella", "Mike", "King Arthur");

        return IntStream
                .generate(() -> random.nextInt(0, 5))
                .limit(count)
                .mapToObj((breedValue) -> {
                    Integer age = IntStream
                            .generate(() -> random.nextInt(1, 10))
                            .limit(1).sum();
                    Cat.Breed breed = Cat.Breed.values()[breedValue];
                    String name = IntStream
                            .generate(() -> random.nextInt(0, 4))
                            .limit(1)
                            .mapToObj(catNames::get)
                            .toString();

                    return new Cat(name, age, breed);
                })
                .toList();
    }

    public static long generateFood(int familySize, int skip) {
        if (familySize < 0 || skip < 0) throw new IllegalArgumentException("Input arguments cannot be negative");
        if (skip >= familySize) return 0;

        long result = LongStream.iterate(4, n -> n * 2)
                .limit(familySize)
                .skip(skip)
                .sum();

        if (result <= 0) throw new ArithmeticException("Overflow");

        return result;
    }
}
