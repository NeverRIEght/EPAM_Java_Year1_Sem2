package com.epam.autotasks;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;

public class ShelterService {

    public void assignAttendants(List<ShelterRoom> rooms) {
        if (rooms == null) return;

        AtomicReference<Cat> catAttendant = new AtomicReference<>();

        rooms.forEach(room -> {
            if (room == null) return;
            room.getCats().forEach(cat -> {
                if (cat == null) return;
                if (cat.getAttendant() != null) {
                    catAttendant.set(cat);
                } else {
                    Random random = new Random();
                    int index = random.nextInt(Cat.Staff.values().length);
                    cat.setAttendant(Cat.Staff.values()[index]);
                }
            });
        });
    }

    public List<Cat> getCheckUpList(List<ShelterRoom> rooms, LocalDate date) {
        List<Cat> cats = new ArrayList<>();

        if (date == null) return cats;
        if (rooms == null) return cats;

        rooms.forEach(room -> {
            if (room == null) return;
            List<Cat> roomCats = room.getCats();
            if (roomCats == null) return;
            roomCats.forEach(cat -> {
                if (cat == null) return;
                if (cat.getLastCheckUpDate() == null) return;
                if (cat.getLastCheckUpDate().isBefore(date)) cats.add(cat);
            });
        });

        return cats;
    }

    public List<Cat> getCatsByBreed(List<ShelterRoom> rooms, Cat.Breed breed) {
        List<Cat> cats = new ArrayList<>();

        if (rooms == null) return cats;
        rooms.forEach(room -> {
            if (room == null) return;
            List<Cat> roomCats = room.getCats();
            if (roomCats == null) return;
            roomCats.forEach(cat -> {
                if (cat == null) return;
                if (cat.getBreed() == null) return;
                if (cat.getBreed().equals(breed)) cats.add(cat);
            });
        });

        return cats;
    }
}
