package com.epam.autotasks;

import com.google.common.collect.ImmutableTable;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class CatDataProcessor {

    public ImmutableTable<String, Cat.Breed, Integer> createCatTable(List<Cat> cats) {
        ImmutableTable.Builder<String, Cat.Breed, Integer> builder = ImmutableTable.builder();

        for (Cat cat : cats) {
            String catName = cat.getName();
            if (catName == null || catName.isEmpty()) continue;

            Cat.Breed catBreed = cat.getBreed();
            if (catBreed == null) continue;

            ContestResult catResult = cat.getContestResult();
            if (catResult == null) continue;

            builder.put(catName, catBreed, catResult.getSum());
        }

        return builder.build();
    }

    public JSONArray createCatJson(List<Cat> cats) {
        JSONArray catArray = new JSONArray();

        for (Cat cat : cats) {
            JSONObject catJsonObject = new JSONObject();

            catJsonObject.put("name", cat.getName());
            catJsonObject.put("age", cat.getAge());
            catJsonObject.put("breed", cat.getBreed());
            catJsonObject.put("weight", cat.getWeight());
            catJsonObject.put("awards", cat.getAwards());

            ContestResult catResult = cat.getContestResult();
            if (catResult == null) continue;
            JSONObject contestResultJsonObject = new JSONObject();

            contestResultJsonObject.put("running", catResult.getRunning());
            contestResultJsonObject.put("jumping", catResult.getJumping());
            contestResultJsonObject.put("purring", catResult.getPurring());
            contestResultJsonObject.put("sum", catResult.getSum());

            catJsonObject.put("contestResult", contestResultJsonObject);
            catArray.put(catJsonObject);
        }

        return catArray;
    }
}