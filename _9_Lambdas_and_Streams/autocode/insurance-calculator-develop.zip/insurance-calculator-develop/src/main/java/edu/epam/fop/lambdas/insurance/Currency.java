package edu.epam.fop.lambdas.insurance;

public enum Currency {
  USD,
  EUR,
  GBP,
  AUD
}
