package edu.epam.fop.lambdas.insurance;

public sealed interface Subject permits Person, Car, Accommodation {

}
