package edu.epam.fop.lambdas.calculator;

import edu.epam.fop.lambdas.insurance.*;
import edu.epam.fop.lambdas.insurance.Accommodation.EmergencyStatus;

import java.math.BigInteger;
import java.util.Comparator;
import java.util.Optional;
import java.util.Set;

public final class PersonInsurancePolicies {

    private PersonInsurancePolicies() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static InsuranceCalculator<Person> childrenDependent(int childrenCountThreshold) {
        return entity -> {
            if (entity == null) return Optional.of(InsuranceCoefficient.MIN);
            if (entity.family().isEmpty()
                    || entity.family().get().children() == null
                    || entity.family().get().children().isEmpty()) {
                return Optional.of(InsuranceCoefficient.MIN);
            }

            int childrenCount = entity.family().get().children().size();

            InsuranceCoefficient result = InsuranceCoefficient.of(
                    Math.min((int) (childrenCount * 100.0 / childrenCountThreshold), 100));
            return Optional.of(result);
        };
    }

    public static InsuranceCalculator<Person> employmentDependentInsurance(BigInteger salaryThreshold,
                                                                           Set<Currency> currencies) {
        return entity -> {
            if (entity == null) return Optional.empty();

            if (entity.employmentHistory() == null || entity.employmentHistory().size() < 4) return Optional.empty();
            if (entity.injuries() != null && !entity.injuries().isEmpty()) return Optional.empty();
            if (entity.accommodations() == null || entity.accommodations().isEmpty()) return Optional.empty();

            Employment lastEmployment = entity.employmentHistory().last();
            if (lastEmployment == null) return Optional.empty();
            if (lastEmployment.endDate().isPresent()) return Optional.empty();

            if (lastEmployment.salary().isEmpty()) return Optional.empty();
            RepeatablePayment lastSalary = lastEmployment.salary().get();

            if (lastSalary.currency() == null) return Optional.empty();
            if (!currencies.contains(lastSalary.currency())) return Optional.empty();

            if (lastSalary.amount().compareTo(salaryThreshold) < 0) return Optional.empty();

            return Optional.of(InsuranceCoefficient.of(50));
        };
    }

    public static InsuranceCalculator<Person> accommodationEmergencyInsurance(Set<EmergencyStatus> statuses) {
        //A person must have an accommodation.
        //The calculator must pick the accommodation that is the smallest in area.
        //Check to make sure its emergencyStatus is listed in the statuses parameter.
        //The coefficient is calculated as 100 * (1 - status.ordinal() / totalStatuses).
        //If any of the conditions are not met, Optional.empty must be returned.

        return entity -> {
            if (entity == null) return Optional.empty();
            if (entity.accommodations() == null || entity.accommodations().isEmpty()) return Optional.empty();

            Accommodation smallestAccommodation = entity.accommodations().stream()
                    .min(Comparator.comparing(Accommodation::area))
                    .orElse(null);

            if (smallestAccommodation.emergencyStatus().isEmpty()) return Optional.empty();
            if (!statuses.contains(smallestAccommodation.emergencyStatus().get())) return Optional.empty();

            int totalStatuses = statuses.size();
            int statusOrdinal = smallestAccommodation.emergencyStatus().get().ordinal();

            int result = (int) (100 * (1 - statusOrdinal * 0.4 / totalStatuses));

            return Optional.of(InsuranceCoefficient.of(result));
        };
    }

    public static InsuranceCalculator<Person> injuryAndRentDependentInsurance(BigInteger rentThreshold) {
        return entity -> {
            if (entity == null || entity.injuries() == null || entity.injuries().isEmpty()) return Optional.empty();

            Injury lastInjury = entity.injuries().last();
            if (lastInjury == null) return Optional.empty();
            if (lastInjury.culprit().isEmpty()) return Optional.empty();

            if (entity.accommodations() == null || entity.accommodations().isEmpty()) return Optional.empty();
            Accommodation largestAccommodation = entity.accommodations().stream()
                    .max(Comparator.comparing(Accommodation::area))
                    .orElse(null);

            if (largestAccommodation.rent().isEmpty()) return Optional.empty();
            if (!largestAccommodation.rent().get().currency().equals(Currency.GBP)) return Optional.empty();

            BigInteger rent = largestAccommodation.rent().get().amount();
            BigInteger result = rent.multiply(BigInteger.valueOf(100)).divide(rentThreshold);

            return Optional.of(InsuranceCoefficient.of(Math.min(100, result.intValue())));
        };
    }
}
