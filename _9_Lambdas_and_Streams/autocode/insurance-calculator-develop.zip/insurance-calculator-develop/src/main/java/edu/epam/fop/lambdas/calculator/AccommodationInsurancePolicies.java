package edu.epam.fop.lambdas.calculator;

import edu.epam.fop.lambdas.insurance.Accommodation;
import edu.epam.fop.lambdas.insurance.Currency;

import java.math.BigInteger;
import java.util.Optional;

public final class AccommodationInsurancePolicies {

    private AccommodationInsurancePolicies() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    static InsuranceCalculator<Accommodation> rentDependentInsurance(BigInteger divider) {
        return entity -> {
            if (entity == null || entity.rent().isEmpty()) return Optional.empty();

            return entity.rent()
                    .filter(rent -> rent.unit().getMonths() > 0 && rent.unit().getMonths() <= 12)
                    .filter(rent -> rent.currency().equals(Currency.USD))
                    .filter(rent -> rent.amount().compareTo(BigInteger.ZERO) > 0)
                    .map(rent -> {
                        int value = (int) (rent.amount().doubleValue() / divider.doubleValue() * 100);
                        if (value > 100) value = 100;
                        return new InsuranceCoefficient(value);
                    });
        };
    }

    static InsuranceCalculator<Accommodation> priceAndRoomsAndAreaDependentInsurance(
            BigInteger priceThreshold,
            int roomsThreshold, BigInteger areaThreshold) {

        return entity -> {
            if (entity == null) return Optional.of(InsuranceCoefficient.MIN);

            boolean price = entity.price() != null && entity.price().compareTo(priceThreshold) >= 0;
            boolean rooms = entity.rooms() != null && entity.rooms() >= roomsThreshold;
            boolean area = entity.area() != null && entity.area().compareTo(areaThreshold) >= 0;

            return Optional.of(price && rooms && area ? InsuranceCoefficient.MAX : InsuranceCoefficient.MIN);
        };
    }
}
