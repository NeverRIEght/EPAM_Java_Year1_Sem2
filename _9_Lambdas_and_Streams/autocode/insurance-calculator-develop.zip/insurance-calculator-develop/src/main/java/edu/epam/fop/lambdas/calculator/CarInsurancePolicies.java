package edu.epam.fop.lambdas.calculator;

import edu.epam.fop.lambdas.insurance.Car;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.Period;
import java.util.Optional;

public final class CarInsurancePolicies {

    private CarInsurancePolicies() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static InsuranceCalculator<Car> ageDependInsurance(LocalDate baseDate) {
        return entity -> {
            if (entity == null || entity.manufactureDate() == null) return Optional.empty();

            int age = Period.between(entity.manufactureDate(), baseDate).getYears();
            if (age <= 1) {
                return Optional.of(InsuranceCoefficient.MAX);
            } else if (age <= 5) {
                return Optional.of(InsuranceCoefficient.of(70));
            } else if (age <= 10) {
                return Optional.of(InsuranceCoefficient.of(30));
            } else {
                return Optional.of(InsuranceCoefficient.MIN);
            }
        };
    }

    public static InsuranceCalculator<Car> priceAndOwningOfFreshCarInsurance(
            LocalDate baseDate,
            BigInteger priceThreshold, Period owningThreshold) {

        //soldDate must not be set.
        //price must be >= than priceThreshold.
        //purchaseDate + owningThreshold must be >= baseDate.
        //InsuranceCoefficient.MAX must be returned if price >= 3 * priceThreshold.
        //A coefficient of 50 must be returned if 3 * priceThreshold > price >= 2 * priceThreshold.
        //InsuranceCoefficient.MIN must be returned if price < 2 * priceThreshold.
        //Optional.empty must be returned if any of the conditions are not met.

        return entity -> {
            if (entity == null || entity.price() == null || entity.purchaseDate() == null) return Optional.empty();

            if (entity.soldDate().isPresent()) return Optional.empty();
            if (entity.price().compareTo(priceThreshold) < 0) return Optional.empty();
            if (entity.purchaseDate().plus(owningThreshold).isBefore(baseDate)) return Optional.empty();

            BigInteger upperBound = priceThreshold.multiply(BigInteger.valueOf(3));
            BigInteger lowerBound = priceThreshold.multiply(BigInteger.valueOf(2));

            if (entity.price().compareTo(upperBound) >= 0) {
                return Optional.of(InsuranceCoefficient.MAX);
            } else if (entity.price().compareTo(lowerBound) >= 0) {
                return Optional.of(InsuranceCoefficient.of(50));
            } else {
                return Optional.of(InsuranceCoefficient.MIN);
            }
        };
    }
}
