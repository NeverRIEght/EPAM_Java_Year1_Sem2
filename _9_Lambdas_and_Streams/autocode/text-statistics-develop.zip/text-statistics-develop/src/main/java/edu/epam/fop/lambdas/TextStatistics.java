package edu.epam.fop.lambdas;

import edu.epam.fop.lambdas.Token.Type;

import java.util.Set;

public final class TextStatistics {
    private TextStatistics() {
        throw new UnsupportedOperationException();
    }

    public static TokenStatisticsCalculator<Token, Long> countTokens() {
        return (map, iterator) -> iterator.forEachRemaining(token -> map.merge(token, 1L, Long::sum));
    }

    public static TokenStatisticsCalculator<Token, Long> countKnownTokensWithMaxLimit(int maxLimit) {
        return (map, iterator) -> iterator.forEachRemaining(token -> {
                    map.computeIfPresent(token, (k, v) -> v < maxLimit ? v + 1 : v);
                });
    }

    public static TokenStatisticsCalculator<Token, Boolean> findUnknownTokensOfTypes(Set<Type> types) {
        return (map, iterator) -> iterator.forEachRemaining(token -> {
            if (types.contains(token.type())) map.computeIfAbsent(token, k -> true);
        });
    }

    public static TokenStatisticsCalculator<Token, Integer> combinedSearch(int maxLimit, Set<Type> types) {
        return (map, iterator) -> iterator.forEachRemaining(token -> {
            map.compute(token, (k, v) -> {
                if (v == null) return -1;

                if (types.contains(token.type())) {
                    return v < maxLimit ? 0 : 1;
                } else {
                    return v < maxLimit ? 2 : 3;
                }
            });
        });
    }

}
