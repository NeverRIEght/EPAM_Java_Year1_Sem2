package com.epam.autotasks;

import java.util.Comparator;
import java.util.List;

public class CatSelection {

    public List<Cat> getFirstNCatsSortedByComparator(List<Cat> cats, Comparator<Cat> comparator, int number) {
        return cats.stream()
                .sorted(comparator)
                .limit(number)
                .toList();
    }

    public List<Cat> getWithoutFirstNCatsSortedByComparator(List<Cat> cats, Comparator<Cat> comparator, int number) {
        return cats.stream()
                .sorted(comparator)
                .skip(number)
                .toList();
    }

    public List<Cat> getSmallCats(List<Cat> cats, int threshold) {
        if (threshold < 0) throw new IllegalArgumentException("Threshold must be positive");
        if (threshold > 15) throw new IllegalArgumentException("Threshold must be lower");

        return cats.stream()
                .sorted(Comparator.comparing(Cat::getWeight))
                .takeWhile(cat -> cat.getWeight() < threshold)
                .toList();
    }

    public List<Cat> getTallCats(List<Cat> cats, int threshold) {
        if (threshold < 0) throw new IllegalArgumentException("Threshold must be positive");
        if (threshold > 100) throw new IllegalArgumentException("Threshold must be lower");

        return cats.stream()
                .sorted(Comparator.comparing(Cat::getHeight).reversed())
                .takeWhile(cat -> cat.getHeight() > threshold)
                .toList();
    }

    public List<String> getUniqueNames(List<Cat> cats) {
        return cats.stream()
                .map(Cat::getName)
                .distinct()
                .toList();
    }
}