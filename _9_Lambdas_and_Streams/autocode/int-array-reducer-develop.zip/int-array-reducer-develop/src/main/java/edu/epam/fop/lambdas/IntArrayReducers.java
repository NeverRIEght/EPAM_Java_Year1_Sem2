package edu.epam.fop.lambdas;

import java.util.Arrays;

// TODO write your implementation here
public interface IntArrayReducers {

    IntArrayReducer SUMMARIZER = array -> Arrays.stream(array).sum();

    IntArrayReducer MULTIPLIER = array -> Arrays.stream(array).reduce(1, (a, b) -> a * b);

    IntArrayReducer MIN_FINDER = array -> Arrays.stream(array).min().getAsInt();

    IntArrayReducer MAX_FINDER = array -> Arrays.stream(array).max().getAsInt();

    IntArrayReducer AVERAGE_CALCULATOR = array -> (int) Math.round(Arrays.stream(array).average().getAsDouble());

    IntArrayReducer UNIQUE_COUNTER = array -> (int) Arrays.stream(array).distinct().count();

    IntArrayReducer SORT_DIRECTION_DEFINER = array -> Integer.compare(array[array.length - 1], array[0]);

}
