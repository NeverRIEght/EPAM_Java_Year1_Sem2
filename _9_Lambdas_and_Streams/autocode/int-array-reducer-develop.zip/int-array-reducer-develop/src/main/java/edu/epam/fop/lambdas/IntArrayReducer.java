package edu.epam.fop.lambdas;

@FunctionalInterface
public interface IntArrayReducer {

  int reduce(int[] array);
}
