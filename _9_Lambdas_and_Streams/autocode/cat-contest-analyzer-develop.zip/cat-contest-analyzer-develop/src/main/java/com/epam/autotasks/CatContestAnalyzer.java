package com.epam.autotasks;

import java.util.*;
import java.util.function.Function;

public class CatContestAnalyzer {

    public static final Integer DEFAULT_VALUE = -1;
    public final Function<List<Cat>, List<Cat>> getCatsSortedByResult = (cats) -> cats.stream()
            .filter(cat -> cat != null && cat.getContestResult() != null)
            .sorted(Comparator.comparingInt(this::getSum).reversed())
            .toList();

    public Integer getMaxResult(List<Cat> cats) {
        if (cats == null) return DEFAULT_VALUE;

        OptionalInt result = cats.stream()
                .filter(cat -> cat != null && cat.getContestResult() != null)
                .mapToInt(cat -> {
                    Integer purring = cat.getContestResult().getPurring();
                    Integer running = cat.getContestResult().getRunning();
                    Integer jumping = cat.getContestResult().getJumping();

                    int sum = purring == null ? 0 : purring;
                    sum += running == null ? 0 : running;
                    sum += jumping == null ? 0 : jumping;

                    return sum;
                }).max();

        return result.isPresent() ? result.getAsInt() : DEFAULT_VALUE;
    }

    public Integer getMinResult(List<Cat> cats) {
        if (cats == null) return DEFAULT_VALUE;

        OptionalInt result = cats.stream()
                .filter(cat -> cat != null && cat.getContestResult() != null)
                .mapToInt(this::getSum)
                .filter(sum -> sum != 0)
                .min();

        return result.isPresent() ? result.getAsInt() : DEFAULT_VALUE;
    }

    public OptionalDouble getAverageResultByBreed(List<Cat> cats, Cat.Breed breed) {
        OptionalDouble result = OptionalDouble.empty();
        if (cats == null) return result;

        result = cats.stream()
                .filter(cat -> cat != null && cat.getContestResult() != null && cat.getBreed() == breed)
                .mapToInt(this::getSum)
                .average();

        return result;
    }

    public Optional<Cat> getWinner(List<Cat> cats) {
        if (cats == null) throw new NullPointerException("cats is null");
        List<Cat> sortedCats = getCatsSortedByResult.apply(cats);
        return sortedCats.isEmpty() ? Optional.empty() : Optional.of(sortedCats.get(0));
    }

    public List<Cat> getThreeLeaders(List<Cat> cats) {
        if (cats == null) throw new NullPointerException("cats is null");
        List<Cat> sortedCats = getCatsSortedByResult.apply(cats);
        return sortedCats.size() > 3 ? sortedCats.subList(0, 3) : sortedCats;
    }

    public boolean validateResultSumNotNull(List<Cat> cats) {
        if (cats == null) throw new NullPointerException("cats is null");
        return cats.stream()
                .noneMatch(cat -> cat != null
                        && cat.getContestResult() != null
                        && getSum(cat) == 0);
    }

    public boolean validateAllResultsSet(List<Cat> cats) {
        if (cats == null) throw new NullPointerException("cats is null");
        return cats.stream()
                .noneMatch(cat -> cat != null
                        && cat.getContestResult() != null
                        && (cat.getContestResult().getJumping() == 0
                        || cat.getContestResult().getRunning() == 0
                        || cat.getContestResult().getPurring() == 0));
    }

    public Optional<Cat> findAnyWithAboveAverageResultByBreed(List<Cat> cats, Cat.Breed breed) {
//        return this.getWinner(cats.stream().filter(cat -> cat.getBreed() == breed).toList());
        if (cats == null) throw new NullPointerException("cats is null");
        if (breed == null) throw new NullPointerException("breed is null");

        OptionalDouble averageResult = getAverageResultByBreed(cats, breed);
        if (averageResult.isEmpty()) return Optional.empty();

        return cats.stream()
                .filter(cat -> cat != null && cat.getContestResult() != null && cat.getBreed() == breed &&
                        getSum(cat) > averageResult.getAsDouble())
                .findAny();
    }

    private int getSum(Cat cat) {
        return cat.getContestResult().getPurring()
                + cat.getContestResult().getRunning()
                + cat.getContestResult().getJumping();
    }
}