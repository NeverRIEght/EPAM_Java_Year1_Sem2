package com.epam.rd.autotasks.timing;

import java.time.*;
import java.util.*;

public class SchedulingAssistantImpl implements SchedulingAssistant {

    private final Collection<Developer> team;
    private final LocalDate today;

    public SchedulingAssistantImpl(Collection<Developer> team, LocalDate today) {
        this.team = team;
        this.today = today;
    }

    @Override
    public LocalDateTime schedule(long meetingDurationMinutes, MeetingTimingPreferences preferences) {
        if (team == null || today == null || preferences == null) {
            throw new IllegalArgumentException("Arguments cannot be null");
        }

        LocalDate meetingDay = getMeetingDay(preferences);
        if (meetingDay == null) return null;

        MeetingPeriod commonMeetingPeriod = null;

        for (Developer developer : team) {
            ZoneId initialTimeZone = getDeveloperZone(developer);
            LocalTime developerStartTime = developer.workDayStartTime;
            ZonedDateTime developerStartTimeUTC = ZonedDateTime.of(today, developerStartTime, initialTimeZone)
                    .withZoneSameInstant(ZoneId.of("UTC"));

            LocalTime localTimeUTC = developerStartTimeUTC.toLocalTime();

            LocalDateTime localDateTime = LocalDateTime.of(meetingDay, localTimeUTC);
            MeetingPeriod developerMeetingPeriod = new MeetingPeriod(localDateTime, localDateTime.plusHours(8).minusMinutes(meetingDurationMinutes));

            if (commonMeetingPeriod == null) {
                commonMeetingPeriod = developerMeetingPeriod;
            } else {
                commonMeetingPeriod = commonMeetingPeriod.getIntersection(developerMeetingPeriod);
                if (commonMeetingPeriod == null) return null;
            }
        }

        if (commonMeetingPeriod == null) return null;

        if (preferences.inPeriod.equals(MeetingTimingPreferences.InPeriodPreference.EARLIEST)) {
            return commonMeetingPeriod.startTime;
        } else {
            return commonMeetingPeriod.endTime;
        }
    }

    private ZoneId getDeveloperZone(Developer dev) {
        Set<String> zones = ZoneId.getAvailableZoneIds();
        String city = dev.city.replace(" ", "_");
        for (String zone : zones) {
            if (zone.contains(city)) return ZoneId.of(zone);
        }

        throw new IllegalArgumentException("No such zone");
    }

    private LocalDate getMeetingDay(MeetingTimingPreferences preferences) {
        switch (preferences.period) {
            case TODAY -> {
                return today;
            }
            case TOMORROW -> {
                return today.plusDays(1);
            }
            case THIS_WEEK -> {
                return resolveWeekDay(preferences);
            }
        }

        return null;
    }

    private LocalDate resolveWeekDay(MeetingTimingPreferences preferences) {
        if (preferences.inPeriod == MeetingTimingPreferences.InPeriodPreference.EARLIEST) {
            return today;
        } else {
            switch (today.getDayOfWeek()) {
                case SUNDAY -> {
                    return today.plusDays(6);
                }
                case MONDAY -> {
                    return today.plusDays(5);
                }
                case TUESDAY -> {
                    return today.plusDays(4);
                }
                case WEDNESDAY -> {
                    return today.plusDays(3);
                }
                case THURSDAY -> {
                    return today.plusDays(2);
                }
                case FRIDAY -> {
                    return today.plusDays(1);
                }
                default -> {
                    return today;
                }
            }
        }
    }

    static class MeetingPeriod {
        LocalDateTime startTime;
        LocalDateTime endTime;

        public MeetingPeriod(LocalDateTime startTime, LocalDateTime endTime) {
            this.startTime = startTime;
            this.endTime = endTime;
        }

        public MeetingPeriod getIntersection(MeetingPeriod other) {
            LocalDateTime start = this.startTime.isAfter(other.startTime) ? this.startTime : other.startTime;
            LocalDateTime end = this.endTime.isBefore(other.endTime) ? this.endTime : other.endTime;

            if (start.isBefore(end) || start.equals(end)) {
                return new MeetingPeriod(start, end);
            }

            return null;
        }

        @Override
        public String toString() {
            return this.getClass().getSimpleName() + " {" +
                    "startTime=" + startTime +
                    ", endTime=" + endTime +
                    '}';
        }
    }
}
