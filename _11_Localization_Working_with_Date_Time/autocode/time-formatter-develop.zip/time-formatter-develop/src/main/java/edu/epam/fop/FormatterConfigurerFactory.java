package edu.epam.fop;

import java.time.format.TextStyle;
import java.time.temporal.*;
import java.time.chrono.Chronology;

public class FormatterConfigurerFactory {

    private FormatterConfigurerFactory() {
    }

    public static FormatterConfigurer slangBasedDate() {
        return builder -> {
            builder.appendText(ChronoField.DAY_OF_MONTH, TextStyle.FULL_STANDALONE);
            builder.appendLiteral(" ");
            builder.appendText(ChronoField.MONTH_OF_YEAR, TextStyle.SHORT);
            builder.appendLiteral(" of ");
            builder.appendValueReduced(ChronoField.YEAR, 2, 4, 1931);
        };
    }

    public static FormatterConfigurer politeScheduler() {
        return builder -> {
            builder.appendLiteral("Scheduled on ");
            builder.appendText(ChronoField.DAY_OF_WEEK, TextStyle.FULL);
            builder.appendLiteral(" at ");
            builder.appendText(ChronoField.CLOCK_HOUR_OF_AMPM);
            builder.appendLiteral(":");
            builder.appendValue(ChronoField.MINUTE_OF_HOUR, 2);
            builder.appendLiteral(" ");
            builder.appendDayPeriodText(TextStyle.SHORT);
            builder.optionalStart();
            builder.appendLiteral(" by ");
            builder.appendZoneText(TextStyle.FULL);
            builder.optionalEnd();
        };
    }

    public static FormatterConfigurer scientificTime() {
        //The builder configured by the scientificTime method must return a String in the following format:
        //
        //[time].[second fraction]
        //time is a simply hours, minutes, and seconds separated by colon. Each of them must be represented by 2 symbols exactly, i.e. that 2 hours must be formatted as 02.
        //second fraction is a micro-seconds which must contain from 1 up to 6 symbols, e.g. 123456 => 123456, 123000 => 123, and 0 => 0

        return builder -> {
            builder.appendValue(ChronoField.HOUR_OF_DAY, 2);
            builder.appendLiteral(":");
            builder.appendValue(ChronoField.MINUTE_OF_HOUR, 2);
            builder.appendLiteral(":");
            builder.appendValue(ChronoField.SECOND_OF_MINUTE, 2);
            builder.appendFraction(ChronoField.MICRO_OF_SECOND, 1, 6, true);
        };
    }

    public static FormatterConfigurer historicalCalendar() {
        //The builder configured by the historicalCalendar method must return a String in the following format:
        //
        //[year of era] of [era] ([chronology])
        //year of era is a year which is tied to the certain era, e.g. 145 AD is 145, but 145 BC is -146
        //era is a full name of the date era, e.g. Before Christ or Anno Domini
        //chronology is a name of calendar which is used for this date
        //Java supports multiple chronologies, such as ISO, Japanese, Minguo, etc. java.time.Chronology is used to describe them. They have different eras, different start date (e.g. Japanese and Hijrah do not support dates before certain point). In the tests you may see how the same date in ISO system might be represented by these chronologies. And you will implement correct formatting rules for that.
        return builder -> {
            System.out.println(Chronology.getAvailableChronologies());
            builder.appendValue(ChronoField.YEAR_OF_ERA);
            builder.appendLiteral(" of ");
            builder.appendText(ChronoField.ERA, TextStyle.FULL);
            builder.appendLiteral(" (");
            builder.appendChronologyText(TextStyle.FULL);
            builder.appendLiteral(")");
        };
    }
}
