package com.epam.rd.autotasks.validations;

public class EpamEmailValidation {

    public static boolean validateEpamEmail(String email) {
        return email != null && email.matches("^\\w+_\\w+\\d*@epam\\.com$");
    }
}