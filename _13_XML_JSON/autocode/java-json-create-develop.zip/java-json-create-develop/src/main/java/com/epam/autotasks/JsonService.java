package com.epam.autotasks;

import java.io.File;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;

public class JsonService {

    @SneakyThrows
    public void createAnimalJson(String filePath, List<Animal> animals) {
        File file = checkFile(filePath);
        if (animals == null) throw new IllegalArgumentException("List of animals is null");

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

        objectMapper.writeValue(file, animals);
    }

    private File checkFile(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) throw new IllegalArgumentException("File not found");
        if (!file.isFile()) throw new IllegalArgumentException("Not a file");
        if (!file.canRead()) throw new IllegalArgumentException("Can't read file");
        return file;
    }
}
