package edu.epam.fop.json.warehouse;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import edu.epam.fop.json.warehouse.item.Item;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.List;

public class WarehouseReaderImpl implements WarehouseReader {
    @Override
    public Collection<Item> readItems(InputStream data) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();

        try {
            return objectMapper.readValue(data, new TypeReference<List<Item>>(){});
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
